# fwBox + DecalsPatch (Enhanced) — v1.0.0

**Author:** JaliscoGDL — special thanks to **Tanuki** for sharing source insights
**Credits:** Enormous thanks to **Tanuki** for source insights.  
Official page: [Tanuki’s fwBox Streamer + Decals Patch (Enhanced)](https://www.gta5-mods.com/scripts/tanuki-s-fwbox-streamer-decals-patch-enhanced)


**Short name:** fwBox + DecalsPatch (Enhanced)
**Long description:** Tanuki’s fwBox Streamer + Decals Limit Patch (Enhanced)
**Credits:** Enormous thanks to **Tanuki** for the groundwork that made the fwBox handling practical.

---

## Quick Start

* **Decals:** Preset **2 = 896** (modern, safe).
* **fwBox:** Shipped default is **`Imm=0x1004` (4100)** = vanilla behavior. To add headroom on modded installs, set **`Imm=0x1400`–`0x1800`**.

> TL;DR: If you crash in heavy scenes, raise fwBox from 4100 → **5120** or **6144**.

---

## What it does

* **Decals Limit Patch:** Finds the two vanilla `cmp r32, imm32` checks that cap world decals (bullet holes, skid marks, scorch, etc.) at low values (`0x100` / `0x200`) and **hard‑patches** them to a safer modern limit (default **896**). This helps prevent **silent CTDs** and aggressive decal culling during combat, crashes, and high‑action scenes.
* **fwBox Streamer Assist:** Locates the **fwBox** streaming guard compare and updates its immediate value (vanilla **`0x1004` = 4100**) via AOB with a fallback **sweeper** when signatures shift between builds. Raising this threshold reduces premature throttling/early bailouts on Enhanced.
* **Logging:** Clean, timestamped `DecalPatch.log`, **cleared on every startup**.

---

## Requirements

* **GTA V Expanded & Enhanced (PC)** (up to date).
* **ScriptHookV (Alexander Blade)** for Enhanced (ASI loader via `xinput1_4.dll`).
* **Microsoft Visual C++ Redistributable 2015–2022 (x64)** (recommended).

> If ASIs don’t load or the game won’t start: ensure `xinput1_4.dll` sits next to `GTA5.exe` and your ScriptHookV matches your build.

---

## Installation

1. Copy **`DecalPatch.asi`** and **`DecalPatch.ini`** into your GTA V Enhanced game folder (where `GTA5.exe` lives).
2. Make sure **ScriptHookV** files are present (notably `xinput1_4.dll`).
3. Install **VC++ 2015–2022 x64** if you’ve never installed it.
4. Launch the game. A fresh **`DecalPatch.log`** will be created on boot.

---

## Configuration (`DecalPatch.ini`)

```ini
[Decals]
; 0=512, 1=768, 2=896, 3=1024, 4=2048  (2 is recommended default)
Preset=2

[fwBox]
Enable=1
; Shipped default keeps vanilla behavior (no change):
Imm=0x1004        ; 4100 (vanilla)
; Suggested for modded installs (uncomment ONE and adjust as needed):
; Imm=0x1400      ; 5120 = safe bump
; Imm=0x1800      ; 6144 = balanced
; Imm=0x2000      ; 8192 = heavy setups (strong PCs)
DetectionOnly=0   ; 1 = scan/log only (no write)

[Log]
Runtime=0         ; 1 = enable extra runtime logging
```

---

## Decals Presets (what they mean)

| Preset | Patched Limit | Notes                                           |
| -----: | ------------: | ----------------------------------------------- |
|      0 |           512 | Vanilla‑adjacent (legacy); may still cull early |
|      1 |           768 | Safer than stock; mild improvement              |
|  **2** |       **896** | **Recommended** modern safe limit               |
|      3 |          1024 | Higher headroom; usually fine                   |
|      4 |          2048 | Ultra; use only if you need it                  |

> These change the two internal `cmp r32, imm32` decaling checks from `0x100/0x200` to the selected limit.

---

## fwBox Streamer Threshold (user guide)

Rockstar hard‑coded **`0x1004` = 4100** as the streaming guard. When the running load reaches this number, the guard trips. Raising it gives the engine more breathing room under heavy modding.

### Recommended Levels

| Level        | INI `Imm=` | Decimal | Recommended For               | Pros                  | Cons                                   |
| ------------ | ---------- | ------: | ----------------------------- | --------------------- | -------------------------------------- |
| **Vanilla**  | `0x1004`   |    4100 | Everyone baseline             | 100% stock, safest    | May trip early on heavy mods           |
| **Safe**     | `0x1400`   |    5120 | Light/modded installs         | Fewer premature trips | Modest change only                     |
| **Balanced** | `0x1800`   |    6144 | Mid/high PCs, many add‑ons    | Common sweet spot     | Slight pop‑in risk if hardware is weak |
| **Heavy**    | `0x2000`   |    8192 | Very heavy setups, strong PCs | Lots of headroom      | Can mask bottlenecks (late assets)     |
| **Extreme**  | `0x2400+`  |   9216+ | Stress‑testing only           | Guard rarely trips    | Noticeable late pop‑in/hangs           |

### How to choose

* Stable on stock? **Stay at 4100.**
* Crashing in dense scenes? Try **5120** → if needed **6144**.
* Extreme builds on strong PCs? **8192**.
* Avoid **9216+** unless testing.

### How to set

1. Open `DecalPatch.ini` → `[fwBox]`.
2. Set `Imm=` to your chosen hex value.
3. Save and launch. Check `DecalPatch.log` to confirm the new immediate.

### Verify the patch site (optional)

* Set `DetectionOnly=1` to log/confirm the site without writing.
* Switch back to `DetectionOnly=0` to apply.

---

## Logging

* All actions write to **`DecalPatch.log`** in the game folder.
* The log is cleared at each startup (fresh session each run).

---

## Uninstall

* Delete **`DecalPatch.asi`** and **`DecalPatch.ini`** from your game folder.

---

## Permissions

You **may not** redistribute, repackage, upload, or mirror this mod without prior permission. If you reference it, provide **proper credit** and a **link back to this official page**. Do not include it in modpacks or rehosts.
