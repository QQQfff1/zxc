@echo off
set GameSavesFolder="C:\Users\Public\Documents\Rockstar Games Saves\GTA V\LieHuoShenJun"
if not exist %GameSavesFolder% (
	md %GameSavesFolder%
)
start explorer %GameSavesFolder%