@echo off
set GameSavesFolder="C:\Users\%USERNAME%\AppData\Roaming\Goldberg SocialClub Emu Saves\GTA V\0F74F4C4"
if not exist %GameSavesFolder% (
	md %GameSavesFolder%
)
start explorer %GameSavesFolder%