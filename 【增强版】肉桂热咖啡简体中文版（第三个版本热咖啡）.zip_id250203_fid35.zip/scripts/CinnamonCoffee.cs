using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using GTA;
using GTA.Native;
using GTA.Math;

/// <summary>
/// CinnamonCoffee - 一个成人 GTA V ScriptHookVDotNet v3 模组。
/// 基于 GTA Vs 和 GTA IV 的 HotCoffee 脚本为 SHVDN v3 API 改编。
/// 
/// 要求:
///   - ScriptHookV (by Alexander Blade)
///   - ScriptHookVDotNet v3 (社区 .NET 封装)
///   - 将此 .cs (或编译后的 .dll) 放入 GTA V /scripts/ 文件夹
///
/// 控制:
///   J          = 打开/关闭菜单
///   小键盘8/2 = 导航菜单
///   小键盘5   = 选择菜单选项
///   小键盘0   = 返回(子菜单) / 关闭菜单
///   小键盘4/6 = 改变速度(动画播放时)
///   小键盘1   = 重置速度(动画播放时)
/// </summary>

namespace CinnamonCoffee
{
    public class CinnamonCoffee : Script
    {
        // ── 状态 ──────────────────────────────────────────────
        private enum ScriptState { Idle, Approaching, Animating }
        private ScriptState state = ScriptState.Idle;
        private bool playerWasInVehicle = false;

        // ── 模式 ───────────────────────────────────────────────
        private enum Mode { None, Car, Street }
        private Mode mode = Mode.None;

        // ── 车辆动画类型 ─────────────────────────────────────────────
        private enum VehicleAnimType { Normal, Low }
        private VehicleAnimType vehicleAnimType = VehicleAnimType.Normal;

        // ── 女孩 ───────────────────────────────────────────────
        private Ped girl = null;
        private bool hasGirl = false;

        // ── 搭讪(卖淫模式) ───────────────────────────────────────
        private int approachPhase = 0;        // 0=行走, 1=开场, 2=等待循环, 3=结束(接受), 4=拒绝, 5=拒绝结束, 6=性感姿势
        private int jHoldStart = 0;           // 第一次按下 J 的游戏时间 (0 = 未按住)
        private int approachAnimWait = 0;     // 当前搭讪动画结束的游戏时间
        private int approachSexySwapTime = 0; // 下次性感动画切换的游戏时间
        private int approachDecisionTimer = 0; // 45秒耐心等待结束的游戏时间
        private string approachDict = "";     // 为该妓女随机选择的动画字典
        private Vector3 approachTargetPos;    // 女孩要走到的世界坐标(车窗或玩家位置)
        private float approachHeading;        // 面向玩家的方向，用于搭讪动画
        private static readonly string[] HOOKER_APPROACH_DICTS = {
            "mini@hookers_spvanilla",
            "mini@hookers_spcokehead",
            "mini@hookers_spcrackhead",
            "mini@hookers_spfrench"
        };
        private static readonly string[] HOOKER_SEXY_ANIMS = {
            "idle_a", "idle_b", "idle_c", "idle_d"
        };

        // ── 菜单 ───────────────────────────────────────────────
        private enum MenuLevel { None, Main, Services }
        private MenuLevel menuLevel = MenuLevel.None;
        private int menuIndex = 0;
        private bool negotiateMode = false; // 每项滑动: false=接受, true=砍价

        // ── 动态定价(按角色缓存) ──────────────────────────────────
        private enum PriceGroup { Kissing, Blowjob, Facesitting, Cowgirl, Doggy }
        private static readonly int[][] PRICE_RANGES = {
            new[] { 20, 80 },   // 接吻:      $20–$80
            new[] { 20, 60 },   // 口交:      $20–$60
            new[] { 20, 60 },   // 坐脸:      $20–$60
            new[] { 40, 80 },   // 女上位:    $40–$80
            new[] { 40, 100 }   // 后入式:    $40–$100
        };
        // 每组砍价成功率(固定，每次尝试)
        private static readonly double[] NEGOTIATE_CHANCE = {
            0.35,   // 接吻:      35%
            0.40,   // 口交:      40%
            0.50,   // 坐脸:       50%
            0.30,   // 女上位:     30%
            0.20    // 后入式:     20%
        };
        // 每组服务对某个妓女是否可用的概率(每个角色只掷一次)
        // 索引与 PriceGroup 枚举一致: 接吻, 口交, 坐脸, 女上位, 后入式
        private static readonly double[] GROUP_AVAIL_CHANCE = {
            0.15,   // 接吻:      15% 可用
            0.60,   // 口交:      60% 可用  (全部3种口交变体)
            0.20,   // 坐脸:       20% 可用
            0.55,   // 女上位:     55% 可用  (全部4种女上位变体)
            0.40    // 后入式:     40% 可用  (两种后入变体)
        };
        // pedHandle → 价格[5] 和 锁定[5]
        private static readonly Dictionary<int, int[]> priceCache = new Dictionary<int, int[]>();
        // pedHandle → 每组锁定[5] — true = 不能再降价
        private static readonly Dictionary<int, bool[]> priceLocked = new Dictionary<int, bool[]>();
        // pedHandle → 每组可用性[5] (true = 该组全部可用)
        private static readonly Dictionary<int, bool[]> availabilityCache = new Dictionary<int, bool[]>();

        private readonly string[] carServiceItems = {
            "口交", "性交"
        };

        private readonly string[] streetServiceItems = {
            "接吻",
            "坐脸",
            "站立口交",
            "坐着口交",
            "躺着口交",
            "靠墙性交",
            "坐着女上位",
            "反向女上位",
            "躺着女上位",
            "躺着反向女上位",
            "后入式",
            "粗暴后入式"
        };

        // ── 设置(保存到文件) ───────────────────────────────────────
        private bool dildoEnabled = true;
        private bool driveableCar = false;
        private bool femaleServiceVoice = true;
        private bool femaleMoanVoice = true;
        private bool femaleEndVoice = true;
        private bool sandboxMode = true;
        private const string SETTINGS_FILE = "scripts\\CinnamonCoffee.cfg";

        // ── 车辆动画覆盖列表(从 .cfg 读取的车型名) ─────────────────────
        private HashSet<int> overwriteLowVehicle = new HashSet<int>();
        private HashSet<int> overwriteNormalVehicle = new HashSet<int>();

        // ── 动画 ──────────────────────────────────────────────────
        private string currentMaleAnim, currentFemaleAnim;
        private string currentMaleDict, currentFemaleDict;
        private string currentAction = ""; // "口交", "性交", "接吻"
        private int animPhase = 0; // 0=开场第1部分, 1=开场第2部分, 2=循环, 3=结束第1部分, 4=结束第2部分
        private int animWaitTime = 0; // 游戏时间戳: 在此时间之前不推进阶段

        // ── 随机/语音 ─────────────────────────────────────────────────
        private static readonly Random rng = new Random();
        private static readonly string[] HOOKER_VOICES = {
            "S_F_Y_HOOKER_01_WHITE_FULL_01",
            "S_F_Y_HOOKER_01_WHITE_FULL_02",
            "S_F_Y_HOOKER_01_WHITE_FULL_03",
            "S_F_Y_HOOKER_02_WHITE_FULL_01",
            "S_F_Y_HOOKER_02_WHITE_FULL_02",
            "S_F_Y_HOOKER_02_WHITE_FULL_03",
            "S_F_Y_HOOKER_03_BLACK_FULL_01",
            "S_F_Y_HOOKER_03_BLACK_FULL_02",
            "S_F_Y_HOOKER_03_BLACK_FULL_03"
        };
        private static readonly Dictionary<int, string> voiceCache = new Dictionary<int, string>();
        private static readonly Dictionary<int, string> approachDictCache = new Dictionary<int, string>();

        // ── 计时/冷却 ──────────────────────────────────────────────────
        private int keyCooldown = 0;
        private int lastVoiceTime = 0;
        private int lastShakeTime = 0;
        private const int VOICE_INTERVAL = 7000;
        private const int KEY_COOLDOWN_FRAMES = 20;
        private float animSpeed = 1.0f; // 循环动画速度倍率
        private int speedCooldown = 0; // 速度改变键冷却

        // ── 生命恢复 ────────────────────────────────────────────────────
        private int lastHealTime = 0;
        private const int HEAL_INTERVAL = 3000; // 每3秒恢复一次
        private const int HEAL_AMOUNT = 2; // 每次基础恢复量(非常少)
        private const int FINISH_HEAL = 1; // 结束时额外恢复
        private bool healPlayer = false;
        private bool healGirl = false;
        private float healRate = 1.0f;

        // ── 退款跟踪(卖淫模式) ────────────────────────────────────────
        private int lastPaidAmount = 0;

        // ── 道具附着 ─────────────────────────────────────────────────────
        private Prop dildoProp = null;
        private int streetActionIdx = -1; // 跟踪街头动作索引，用于道具偏移

        // ── 车内搭讪姿势 ────────────────────────────────────────────────
        private bool carPropActive = false;   // 当前处于或正在进入/退出搭讪姿势
        private int carPropPhase = 0;         // 0=进入中, 1=循环中, 2=退出中
        private int carPropWaitTime = 0;      // 当前姿势动画结束的游戏时间

        // ── 车内动画字典名称 ────────────────────────────────────────────
        private const string VEH_NORM_DICT = "mini@prostitutes@sexnorm_veh";
        private const string VEH_NORM_FP_DICT = "mini@prostitutes@sexnorm_veh_first_person";
        private const string VEH_LOW_DICT = "mini@prostitutes@sexlow_veh";
        private const string VEH_LOW_FP_DICT = "mini@prostitutes@sexlow_veh_first_person";

        // ═══════════
        // 构造函数
        // ═══════════
        public CinnamonCoffee()
        {
            Tick += OnTick;
            KeyDown += OnKeyDown;
            Interval = 0;

            LoadSettings();
        }

        // ════════════
        // 设置 I/O
        // ════════════
        private void LoadSettings()
        {
            try
            {
                if (File.Exists(SETTINGS_FILE))
                {
                    foreach (string line in File.ReadAllLines(SETTINGS_FILE))
                    {
                        string trimmed = line.Trim();
                        if (trimmed.StartsWith("dildoEnabled="))
                            dildoEnabled = trimmed.Substring(13).Trim().ToLower() == "true";
                        else if (trimmed.StartsWith("driveableCar="))
                            driveableCar = trimmed.Substring(13).Trim().ToLower() == "true";
                        else if (trimmed.StartsWith("femaleServiceVoice="))
                            femaleServiceVoice = trimmed.Substring(19).Trim().ToLower() == "true";
                        else if (trimmed.StartsWith("femaleMoanVoice="))
                            femaleMoanVoice = trimmed.Substring(16).Trim().ToLower() == "true";
                        else if (trimmed.StartsWith("femaleEndVoice="))
                            femaleEndVoice = trimmed.Substring(15).Trim().ToLower() == "true";
                        else if (trimmed.StartsWith("sandboxMode="))
                            sandboxMode = trimmed.Substring(12).Trim().ToLower() == "true";
                        else if (trimmed.StartsWith("overwriteLowVehicle="))
                            overwriteLowVehicle = ParseVehicleList(trimmed.Substring(20));
                        else if (trimmed.StartsWith("overwriteNormalVehicle="))
                            overwriteNormalVehicle = ParseVehicleList(trimmed.Substring(23));
                    }
                }
            }
            catch { /* 使用默认值即可 */ }
        }

        private HashSet<int> ParseVehicleList(string csv)
        {
            var set = new HashSet<int>();
            foreach (string part in csv.Split(','))
            {
                string name = part.Trim().ToLower();
                if (name.Length > 0)
                {
                    try { set.Add(Game.GenerateHash(name)); }
                    catch { }
                }
            }
            return set;
        }

        private void SaveSettings()
        {
            try
            {
                // 读取现有文件以保留注释和覆盖列表
                var lines = new List<string>();
                if (File.Exists(SETTINGS_FILE))
                    lines = new List<string>(File.ReadAllLines(SETTINGS_FILE));

                // 跟踪已更新的键
                var updated = new HashSet<string>();
                for (int i = 0; i < lines.Count; i++)
                {
                    string t = lines[i].Trim();
                    if (t.StartsWith("dildoEnabled="))
                    { lines[i] = "dildoEnabled=" + dildoEnabled.ToString().ToLower(); updated.Add("dildoEnabled"); }
                    else if (t.StartsWith("driveableCar="))
                    { lines[i] = "driveableCar=" + driveableCar.ToString().ToLower(); updated.Add("driveableCar"); }
                    else if (t.StartsWith("femaleServiceVoice="))
                    { lines[i] = "femaleServiceVoice=" + femaleServiceVoice.ToString().ToLower(); updated.Add("femaleServiceVoice"); }
                    else if (t.StartsWith("femaleMoanVoice="))
                    { lines[i] = "femaleMoanVoice=" + femaleMoanVoice.ToString().ToLower(); updated.Add("femaleMoanVoice"); }
                    else if (t.StartsWith("femaleEndVoice="))
                    { lines[i] = "femaleEndVoice=" + femaleEndVoice.ToString().ToLower(); updated.Add("femaleEndVoice"); }
                    else if (t.StartsWith("sandboxMode="))
                    { lines[i] = "sandboxMode=" + sandboxMode.ToString().ToLower(); updated.Add("sandboxMode"); }
                    // 所有其他行(注释、覆盖列表)保持原样
                }

                // 追加任何缺失的键(例如第一次运行或手动编辑的文件)
                if (!updated.Contains("dildoEnabled")) lines.Add("dildoEnabled=" + dildoEnabled.ToString().ToLower());
                if (!updated.Contains("driveableCar")) lines.Add("driveableCar=" + driveableCar.ToString().ToLower());
                if (!updated.Contains("femaleServiceVoice")) lines.Add("femaleServiceVoice=" + femaleServiceVoice.ToString().ToLower());
                if (!updated.Contains("femaleMoanVoice")) lines.Add("femaleMoanVoice=" + femaleMoanVoice.ToString().ToLower());
                if (!updated.Contains("femaleEndVoice")) lines.Add("femaleEndVoice=" + femaleEndVoice.ToString().ToLower());
                if (!updated.Contains("sandboxMode")) lines.Add("sandboxMode=" + sandboxMode.ToString().ToLower());

                File.WriteAllLines(SETTINGS_FILE, lines.ToArray());
            }
            catch { }
        }

        // ═══════════════
        // 动态定价
        // ═══════════════

        /// <summary>为每组生成随机价格(10美元步进)和服务可用性，按角色缓存。</summary>
        private void GeneratePedPrices(int pedHandle)
        {
            if (priceCache.ContainsKey(pedHandle)) return;
            int[] prices = new int[5];
            for (int i = 0; i < 5; i++)
                prices[i] = rng.Next(PRICE_RANGES[i][0] / 10, PRICE_RANGES[i][1] / 10 + 1) * 10;
            priceCache[pedHandle] = prices;
            priceLocked[pedHandle] = new bool[] { false, false, false, false, false };

            // 每组可用性掷骰(同组所有服务共用一次掷骰)
            bool[] avail = new bool[5];
            for (int i = 0; i < 5; i++)
                avail[i] = rng.NextDouble() < GROUP_AVAIL_CHANCE[i];
            availabilityCache[pedHandle] = avail;
        }

        /// <summary>检查当前女孩的某项服务是否可用(按组)。</summary>
        private bool IsServiceAvailable(bool isCar, int idx)
        {
            // 车内服务始终可用
            if (isCar) return true;
            if (girl == null) return false;
            int handle = girl.Handle;
            GeneratePedPrices(handle);
            if (!availabilityCache.ContainsKey(handle)) return false;
            int gi = (int)GetServicePriceGroup(false, idx);
            return availabilityCache[handle][gi];
        }

        /// <summary>检查某个价格组是否被锁定(无法继续砍价)。</summary>
        private bool IsPriceLocked(bool isCar, int idx)
        {
            if (girl == null) return true;
            int handle = girl.Handle;
            if (!priceLocked.ContainsKey(handle)) return true;
            return priceLocked[handle][(int)GetServicePriceGroup(isCar, idx)];
        }

        /// <summary>
        /// 尝试降低当前高亮服务的价格组。
        /// 每次尝试: 按组固定成功率。失败 = 永久锁定。
        /// 如果幸运，可以一路砍价到最低价。
        /// </summary>
        private void NegotiatePrice()
        {
            if (girl == null) return;
            bool isCar = (mode == Mode.Car);

            // 不可用的服务不能砍价
            if (!IsServiceAvailable(isCar, menuIndex))
            {
                PlayPedSpeech(girl, "GENERIC_NO");
                return;
            }

            int handle = girl.Handle;
            GeneratePedPrices(handle);
            PriceGroup grp = GetServicePriceGroup(isCar, menuIndex);
            int gi = (int)grp;
            int currentPrice = priceCache[handle][gi];
            int floor = PRICE_RANGES[gi][0];

            // 已锁定
            if (priceLocked[handle][gi])
            {
                PlayPedSpeech(girl, "GENERIC_NO");
                return;
            }

            // 已是最低价 → 自动锁定
            if (currentPrice <= floor)
            {
                priceLocked[handle][gi] = true;
                PlayPedSpeech(girl, "GENERIC_NO");
                return;
            }

            // 每组固定成功率
            if (rng.NextDouble() >= NEGOTIATE_CHANCE[gi])
            {
                // 失败 — 永久锁定
                priceLocked[handle][gi] = true;
                PlayPedSpeech(girl, "GENERIC_NO");
                return;
            }

            // 成功 — 降价10美元
            priceCache[handle][gi] = currentPrice - 10;
            int newPrice = priceCache[handle][gi];

            // 如果正好降到最低价，也锁定
            if (newPrice <= floor)
                priceLocked[handle][gi] = true;

            PlayPedSpeech(girl, "GENERIC_YES");
        }

        /// <summary>将服务菜单项映射到其价格组。</summary>
        private PriceGroup GetServicePriceGroup(bool isCar, int idx)
        {
            if (isCar)
                return idx == 0 ? PriceGroup.Blowjob : PriceGroup.Cowgirl;
            // 街头: 0=接吻, 1=坐脸, 2-4=口交, 5-9=女上位/性交, 10-11=后入
            switch (idx)
            {
                case 0: return PriceGroup.Kissing;
                case 1: return PriceGroup.Facesitting;
                case 2: case 3: case 4: return PriceGroup.Blowjob;
                case 5: case 6: case 7: case 8: case 9: return PriceGroup.Cowgirl;
                case 10: case 11: return PriceGroup.Doggy;
                default: return PriceGroup.Blowjob;
            }
        }

        /// <summary>从当前女孩的缓存价格中获取某项服务的价格。</summary>
        private int GetServicePrice(bool isCar, int idx)
        {
            if (girl == null) return 0;
            int handle = girl.Handle;
            GeneratePedPrices(handle); // 确保已缓存
            return priceCache[handle][(int)GetServicePriceGroup(isCar, idx)];
        }

        // ═════════
        // 按键输入
        // ═════════
        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (menuLevel == MenuLevel.None) return;

            int itemCount = GetCurrentMenuItemCount();

            if (e.KeyCode == Keys.NumPad8)
            {
                menuIndex = (menuIndex - 1 + itemCount) % itemCount;
                negotiateMode = false; // 换行时重置滑动状态
            }
            else if (e.KeyCode == Keys.NumPad2)
            {
                menuIndex = (menuIndex + 1) % itemCount;
                negotiateMode = false; // 换行时重置滑动状态
            }
            else if (e.KeyCode == Keys.NumPad4 || e.KeyCode == Keys.NumPad6)
            {
                // 左/右滑动切换 接受 ↔ 砍价 (仅在服务子菜单且非沙盒模式)
                if (menuLevel == MenuLevel.Services && !sandboxMode)
                    negotiateMode = !negotiateMode;
            }
            else if (e.KeyCode == Keys.NumPad5)
            {
                HandleMenuSelect();
            }
            else if (e.KeyCode == Keys.NumPad0)
            {
                // 返回上一级或关闭
                if (menuLevel == MenuLevel.Services)
                {
                    // 离开服务菜单时退出车内搭讪姿势
                    if (mode == Mode.Car && carPropActive)
                        ExitCarProposition(Game.Player.Character);
                    menuLevel = MenuLevel.Main;
                    menuIndex = 0;
                    negotiateMode = false;
                }
                else
                {
                    menuLevel = MenuLevel.None;
                    keyCooldown = KEY_COOLDOWN_FRAMES;
                }
            }
            else if (e.KeyCode == Keys.J)
            {
                // 如果车内搭讪姿势激活则退出
                if (mode == Mode.Car && carPropActive)
                    ExitCarProposition(Game.Player.Character);
                // J 总是完全关闭菜单
                menuLevel = MenuLevel.None;
                keyCooldown = KEY_COOLDOWN_FRAMES;
            }
        }

        /// <summary>获取当前菜单级别的项目数。</summary>
        private int GetCurrentMenuItemCount()
        {
            if (menuLevel == MenuLevel.Main)
            {
                // hasGirl: 服务, 释放, 男性裸露, 女性服务语音, 女性呻吟声, 女性结束语音, 可驾驶车辆, 模式 (8项)
                // 无女孩: 搜索, 男性裸露, 女性服务语音, 女性呻吟声, 女性结束语音, 可驾驶车辆, 模式 (7项)
                return hasGirl ? 8 : 7;
            }
            else if (menuLevel == MenuLevel.Services)
            {
                string[] items = (mode == Mode.Car) ? carServiceItems : streetServiceItems;
                return items.Length;
            }
            return 0;
        }

        /// <summary>处理当前菜单级别的项目选择。</summary>
        private void HandleMenuSelect()
        {
            if (menuLevel == MenuLevel.Main)
            {
                // 根据 hasGirl 构建菜单项映射
                if (hasGirl)
                {
                    // 0: 服务 >>, 1: 释放她, 2: 男性裸露开关, 3: 女性服务语音, 4: 女性呻吟声, 5: 女性结束语音, 6: 可驾驶车辆, 7: 模式
                    switch (menuIndex)
                    {
                        case 0: // 服务 >>
                            OpenServicesMenu();
                            break;
                        case 1: // 释放她
                            ShowSubtitle("~y~女人已遣散!", 2000);
                            FullReset();
                            menuLevel = MenuLevel.Main;
                            menuIndex = 0;
                            break;
                        case 2: // 男性裸露开关
                            dildoEnabled = !dildoEnabled;
                            SaveSettings();
                            break;
                        case 3: // 女性服务语音
                            femaleServiceVoice = !femaleServiceVoice;
                            SaveSettings();
                            break;
                        case 4: // 女性呻吟声
                            femaleMoanVoice = !femaleMoanVoice;
                            SaveSettings();
                            break;
                        case 5: // 女性结束语音
                            femaleEndVoice = !femaleEndVoice;
                            SaveSettings();
                            break;
                        case 6: // 可驾驶车辆
                            driveableCar = !driveableCar;
                            SaveSettings();
                            break;
                        case 7: // 模式
                            sandboxMode = !sandboxMode;
                            SaveSettings();
                            break;
                    }
                }
                else
                {
                    // 0: 搜索, 1: 男性裸露开关, 2: 女性服务语音, 3: 女性呻吟声, 4: 女性结束语音, 5: 可驾驶车辆, 6: 模式
                    switch (menuIndex)
                    {
                        case 0: // 搜索最近的女人
                            TryPickup(Game.Player.Character);
                            break;
                        case 1: // 男性裸露开关
                            dildoEnabled = !dildoEnabled;
                            SaveSettings();
                            break;
                        case 2: // 女性服务语音
                            femaleServiceVoice = !femaleServiceVoice;
                            SaveSettings();
                            break;
                        case 3: // 女性呻吟声
                            femaleMoanVoice = !femaleMoanVoice;
                            SaveSettings();
                            break;
                        case 4: // 女性结束语音
                            femaleEndVoice = !femaleEndVoice;
                            SaveSettings();
                            break;
                        case 5: // 可驾驶车辆
                            driveableCar = !driveableCar;
                            SaveSettings();
                            break;
                        case 6: // 模式
                            sandboxMode = !sandboxMode;
                            SaveSettings();
                            break;
                    }
                }
            }
            else if (menuLevel == MenuLevel.Services)
            {
                string[] items = (mode == Mode.Car) ? carServiceItems : streetServiceItems;

                // 阻止不可用的服务(卖淫模式)
                if (!sandboxMode && !IsServiceAvailable(mode == Mode.Car, menuIndex))
                {
                    PlayPedSpeech(girl, "GENERIC_NO");
                    return;
                }

                // 砍价滑动: 按5在"砍价"上触发砍价而不是购买
                if (!sandboxMode && negotiateMode)
                {
                    NegotiatePrice();
                    return;
                }

                // 卖淫模式: 检查金钱(动态定价)
                if (!sandboxMode)
                {
                    int cost = GetServicePrice(mode == Mode.Car, menuIndex);
                    int money = Game.Player.Money;
                    if (money < cost)
                    {
                        PlayPedSpeech(girl, "GENERIC_WHATEVER");
                        return;
                    }
                    Game.Player.Money -= cost;
                    lastPaidAmount = cost;
                }
                else
                {
                    lastPaidAmount = 0;
                }

                // 开始动作前退出搭讪姿势
                // (StartCarAction 会播放从搭讪到服务的自然过渡)
                if (mode == Mode.Car)
                {
                    carPropActive = false;
                    carPropPhase = 0;
                }

                menuLevel = MenuLevel.None;
                keyCooldown = KEY_COOLDOWN_FRAMES;

                if (mode == Mode.Car)
                    StartCarAction(menuIndex);
                else
                    StartStreetAction(menuIndex);
            }
        }

        /// <summary>尝试打开服务子菜单，并进行上下文检查。</summary>
        private void OpenServicesMenu()
        {
            if (!hasGirl || girl == null || !girl.Exists())
            {
                FullReset();
                menuLevel = MenuLevel.Main;
                menuIndex = 0;
                ShowSubtitle("~r~找不到女人!", 2000);
                return;
            }

            Ped player = Game.Player.Character;
            bool pInV = player.IsInVehicle();
            bool gInV = girl.IsInVehicle();

            // 玩家在不合适的车辆中(摩托、船、直升机、飞机)
            if (pInV)
            {
                Vehicle car = player.CurrentVehicle;
                if (car != null && !IsSuitableVehicle(car))
                {
                    ShowSubtitle("~r~不能在这辆车里做!", 3000);
                    return;
                }
            }

            if (pInV && gInV && girl.CurrentVehicle == player.CurrentVehicle)
            {
                mode = Mode.Car;
                menuLevel = MenuLevel.Services;
                menuIndex = 0;
                PlayServiceVoice();
                // 如果尚未进入搭讪姿势，则进入
                if (!carPropActive)
                    EnterCarProposition(player);
            }
            else if (!pInV && !gInV)
            {
                mode = Mode.Street;
                menuLevel = MenuLevel.Services;
                menuIndex = 0;
                PlayServiceVoice();
            }
            else
            {
                ShowSubtitle("~y~正在等她...", 2000);
            }
        }

        // ═════════
        // 主循环
        // ═════════
        private void OnTick(object sender, EventArgs e)
        {
            if (keyCooldown > 0) keyCooldown--;

            Ped player = Game.Player.Character;

            switch (state)
            {
                case ScriptState.Idle:
                    HandleIdleState(player);
                    break;

                case ScriptState.Approaching:
                    HandleApproachingState(player);
                    break;

                case ScriptState.Animating:
                    HandleAnimatingState(player);
                    break;
            }

            // 绘制菜单叠加
            if (menuLevel != MenuLevel.None) DrawMenu();
        }

        // ══════════
        // 空闲状态
        // ══════════
        private void HandleIdleState(Ped player)
        {
            // ── 女孩跟随 + 自动上下车 ──
            if (hasGirl && girl != null && girl.Exists())
            {
                if (!girl.IsAlive)
                {
                    // ShowSubtitle("~r~女人死了!", 2000); - 仅调试用
                    FullReset();
                    return;
                }

                // 卖淫模式: 如果她离得太远，她会离开
                if (!sandboxMode)
                {
                    float girlDist = girl.Position.DistanceTo(player.Position);
                    if (girlDist > 20f)
                    {
                        FullReset();
                        return;
                    }
                }

                bool playerInVeh = player.IsInVehicle();
                bool girlInVeh = girl.IsInVehicle();

                // 玩家刚上车 → 让女孩上车
                if (playerInVeh && !playerWasInVehicle)
                {
                    if (menuLevel == MenuLevel.Services) { menuLevel = MenuLevel.Main; menuIndex = 0; }
                    Vehicle car = player.CurrentVehicle;
                    if (car != null && IsSuitableVehicle(car) &&
                        car.GetPedOnSeat(VehicleSeat.Passenger) == null)
                    {
                        girl.Task.EnterVehicle(car, VehicleSeat.Passenger);
                    }
                }

                // 玩家刚下车 → 让女孩也下车
                if (!playerInVeh && playerWasInVehicle)
                {
                    if (menuLevel == MenuLevel.Services) { menuLevel = MenuLevel.Main; menuIndex = 0; }
                    if (girlInVeh)
                        girl.Task.LeaveVehicle();
                }

                // 步行: 跟随玩家
                if (!playerInVeh && !girlInVeh)
                {
                    girl.BlockPermanentEvents = true;
                    float dist = girl.Position.DistanceTo(player.Position);

                    if (dist > 50f)
                    {
                        FullReset();
                        return;
                    }
                    else if (dist > 2f)
                    {
                        bool isIdle = !Function.Call<bool>(Hash.IS_PED_WALKING, girl) &&
                                      !Function.Call<bool>(Hash.IS_PED_RUNNING, girl);
                        if (isIdle)
                        {
                            float speed = (dist > 7f) ? 3f : 1f;
                            Function.Call(Hash.TASK_FOLLOW_TO_OFFSET_OF_ENTITY,
                                girl, player, 0f, -1f, 0f, speed, -1, 1.5f, true);
                        }
                    }
                    else
                    {
                        bool isMoving = Function.Call<bool>(Hash.IS_PED_WALKING, girl) ||
                                        Function.Call<bool>(Hash.IS_PED_RUNNING, girl);
                        if (isMoving)
                            girl.Task.TurnTo(player);
                    }
                }

                // 上下文检查: 如果服务菜单打开但玩家/女孩上下文改变，强制返回
                if (menuLevel == MenuLevel.Services)
                {
                    bool pInV = player.IsInVehicle();
                    bool gInV = girl.IsInVehicle();
                    bool validCar = pInV && gInV && girl.CurrentVehicle == player.CurrentVehicle;
                    bool validStreet = !pInV && !gInV;
                    if (!validCar && !validStreet)
                    {
                        menuLevel = MenuLevel.Main;
                        menuIndex = 0;
                        ShowSubtitle("~y~正在等她...", 2000);
                    }
                }

                playerWasInVehicle = playerInVeh;

                // ── 车内搭讪姿势管理 ──
                if (carPropActive)
                {
                    // 阶段0 → 1: 进入动画完成 → 开始循环
                    if (carPropPhase == 0 && Game.GameTime >= carPropWaitTime)
                    {
                        int cm = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
                        bool fp = (cm == 4);
                        string pd;
                        if (vehicleAnimType == VehicleAnimType.Low)
                            pd = fp ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
                        else
                            pd = fp ? VEH_NORM_FP_DICT : VEH_NORM_DICT;

                        string fLoop, mLoop;
                        if (vehicleAnimType == VehicleAnimType.Low)
                        { fLoop = "low_car_prop_loop_female"; mLoop = "low_car_prop_loop_player"; }
                        else
                        { fLoop = "proposition_loop_prostitute"; mLoop = "proposition_loop_male"; }

                        Function.Call(Hash.TASK_PLAY_ANIM, girl, pd, fLoop,
                            8.0f, -4.0f, -1, 1, 0.0f, false, false, false);
                        Function.Call(Hash.TASK_PLAY_ANIM, player, pd, mLoop,
                            8.0f, -4.0f, -1, driveableCar ? 33 : 1, 0.0f, false, false, false);
                        carPropPhase = 1;
                    }
                    // 阶段2: 退出动画完成 → 清理
                    else if (carPropPhase == 2 && Game.GameTime >= carPropWaitTime)
                    {
                        carPropActive = false;
                        carPropPhase = 0;
                    }

                    // 后备: 搭讪姿势激活但不在服务菜单中 → 干净退出
                    if (carPropActive && (carPropPhase == 0 || carPropPhase == 1) && menuLevel != MenuLevel.Services)
                    {
                        ExitCarProposition(player);
                    }
                }
            }

            // ── J键: 打开/关闭菜单 ──
            if (Game.IsKeyPressed(Keys.J) && keyCooldown == 0)
            {
                keyCooldown = KEY_COOLDOWN_FRAMES;
                if (menuLevel != MenuLevel.None)
                {
                    menuLevel = MenuLevel.None;
                }
                else
                {
                    menuLevel = MenuLevel.Main;
                    menuIndex = 0;
                }
            }

            if (menuLevel != MenuLevel.None) return;
        }

        // ═══════════════
        // 动画状态
        // ═══════════════
        private void HandleAnimatingState(Ped player)
        {
            if (girl == null || !girl.Exists())
            {
                EndAnimation();
                return;
            }

            // 动画期间禁用手机(控制27 = 手机)
            Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 27, true);

            // 车内模式: 每帧保持座位偏移
            if (mode == Mode.Car)
            {
                // 阻止玩家下车(控制75 = 车辆退出)
                Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 75, true);

                // 如果车辆不可驾驶，禁用车辆移动控制
                if (!driveableCar)
                {
                    Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 71, true);  // 加速
                    Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 72, true);  // 刹车
                    Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 59, true);  // 左右移动
                    Function.Call(Hash.DISABLE_CONTROL_ACTION, 0, 76, true);  // 手刹
                }

                RunCarAnimation(player);
            }

            // 街头模式循环: 在站立口交动画接近结束时重新启动
            if (mode == Mode.Street && animPhase == 2 && currentMaleDict == "misscarsteal2pimpsex" && currentMaleAnim == "pimpsex_punter")
            {
                float mProgress = Function.Call<float>(Hash.GET_ENTITY_ANIM_CURRENT_TIME, player, currentMaleDict, currentMaleAnim);
                float fProgress = Function.Call<float>(Hash.GET_ENTITY_ANIM_CURRENT_TIME, girl, currentFemaleDict, currentFemaleAnim);
                if (mProgress > 0.36f || fProgress > 0.36f)
                {
                    Function.Call(Hash.TASK_PLAY_ANIM, player, currentMaleDict, currentMaleAnim,
                        8.0f, -4.0f, -1, 9, 0.0f, false, false, false);
                    Function.Call(Hash.TASK_PLAY_ANIM, girl, currentFemaleDict, currentFemaleAnim,
                        8.0f, -4.0f, -1, 9, 0.0f, false, false, false);
                    // 循环重启后重新应用自定义速度
                    if (animSpeed != 1.0f)
                    {
                        Function.Call(Hash.SET_ENTITY_ANIM_SPEED, player, currentMaleDict, currentMaleAnim, animSpeed);
                        Function.Call(Hash.SET_ENTITY_ANIM_SPEED, girl, currentFemaleDict, currentFemaleAnim, animSpeed);
                    }
                }
            }

            // 街头模式循环: 粗暴后入式
            if (mode == Mode.Street && animPhase == 2 && currentMaleDict == "trevor_1_int-13")
            {
                float mProgress = Function.Call<float>(Hash.GET_ENTITY_ANIM_CURRENT_TIME, player, currentMaleDict, currentMaleAnim);
                float fProgress = Function.Call<float>(Hash.GET_ENTITY_ANIM_CURRENT_TIME, girl, currentFemaleDict, currentFemaleAnim);
                if (mProgress > 0.650f || fProgress > 0.650f)
                {
                    Function.Call(Hash.TASK_PLAY_ANIM, player, currentMaleDict, currentMaleAnim,
                        8.0f, -4.0f, -1, 9, 0.205f, false, false, false);
                    Function.Call(Hash.TASK_PLAY_ANIM, girl, currentFemaleDict, currentFemaleAnim,
                        8.0f, -4.0f, -1, 9, 0.205f, false, false, false);
                    // 循环重启后重新应用自定义速度
                    if (animSpeed != 1.0f)
                    {
                        Function.Call(Hash.SET_ENTITY_ANIM_SPEED, player, currentMaleDict, currentMaleAnim, animSpeed);
                        Function.Call(Hash.SET_ENTITY_ANIM_SPEED, girl, currentFemaleDict, currentFemaleAnim, animSpeed);
                    }
                }
            }

            // 周期性呻吟(仅在循环阶段，速度平滑缩放)
            int now = Game.GameTime;
            int voiceInterval = (int)(VOICE_INTERVAL / (1.0 + (animSpeed - 1.0) * 0.55));
            if (currentAction != "" && animPhase == 2 && now - lastVoiceTime > voiceInterval)
            {
                PlayMoaningSounds();
                lastVoiceTime = now;
            }

            // 循环阶段缓慢恢复生命
            if (animPhase == 2 && now - lastHealTime > HEAL_INTERVAL)
            {
                int hp = (int)(HEAL_AMOUNT * healRate * (animSpeed > 1.0f ? animSpeed : 1.0f));
                if (healPlayer)
                {
                    player.Health = Math.Min(player.Health + hp, player.MaxHealth);
                }
                if (healGirl && girl != null && girl.Exists())
                {
                    girl.Health = Math.Min(girl.Health + hp, girl.MaxHealth);
                }
                lastHealTime = now;
            }

            // 循环阶段速度控制(小键盘4 = 减慢, 小键盘6 = 加快, 小键盘1 = 重置)
            if (speedCooldown > 0) speedCooldown--;
            if (animPhase == 2 && speedCooldown == 0)
            {
                bool changed = false;
                if (Game.IsKeyPressed(Keys.NumPad6))
                {
                    animSpeed = Math.Min(animSpeed + 0.05f, 3.0f);
                    changed = true;
                }
                else if (Game.IsKeyPressed(Keys.NumPad4))
                {
                    animSpeed = Math.Max(animSpeed - 0.05f, 0.30f);
                    changed = true;
                }
                else if (Game.IsKeyPressed(Keys.NumPad1))
                {
                    animSpeed = 1.0f;
                    changed = true;
                }
                if (changed)
                {
                    speedCooldown = 10;
                    string mDict = currentMaleDict;
                    string fDict = currentFemaleDict;
                    if (mode == Mode.Car)
                    {
                        int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
                        if (camMode == 4) // 第一人称
                        {
                            if (vehicleAnimType == VehicleAnimType.Low)
                            {
                                mDict = VEH_LOW_FP_DICT;
                                fDict = VEH_LOW_FP_DICT;
                            }
                            else
                            {
                                mDict = VEH_NORM_FP_DICT;
                                fDict = VEH_NORM_FP_DICT;
                            }
                        }
                    }
                    Function.Call(Hash.SET_ENTITY_ANIM_SPEED, player, mDict, currentMaleAnim, animSpeed);
                    Function.Call(Hash.SET_ENTITY_ANIM_SPEED, girl, fDict, currentFemaleAnim, animSpeed);
                }
            }

            // 循环阶段持续显示提示
            if (animPhase == 2)
            {
                ShowSubtitle("~b~[J]~s~ 结束 | ~b~[4/6]~s~ 改变速度 | ~b~[1]~s~ 重置速度  [速度: " + animSpeed.ToString("0.00") + "x]", 100);
            }

            // J 键结束/射精/中止
            if (Game.IsKeyPressed(Keys.J) && keyCooldown == 0)
            {
                keyCooldown = KEY_COOLDOWN_FRAMES;

                if (mode == Mode.Car)
                {
                    // 在开场阶段(0, 1) - 立即中止
                    if (animPhase == 0 || animPhase == 1)
                    {
                        // 根据车辆类型获取当前字典
                        int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
                        bool isFirstPerson = (camMode == 4);

                        string dict;
                        if (vehicleAnimType == VehicleAnimType.Low)
                            dict = isFirstPerson ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
                        else
                            dict = isFirstPerson ? VEH_NORM_FP_DICT : VEH_NORM_DICT;

                        // 根据阶段和动作获取当前动画名称
                        string fAnim, mAnim;

                        if (animPhase == 0)
                        {
                            if (currentAction == "口交")
                            {
                                if (vehicleAnimType == VehicleAnimType.Low)
                                {
                                    fAnim = "low_car_prop_to_bj_p1_female";
                                    mAnim = "low_car_prop_to_bj_p1_player";
                                }
                                else
                                {
                                    fAnim = "proposition_to_bj_p1_prostitute";
                                    mAnim = "proposition_to_bj_p1_male";
                                }
                            }
                            else // 性交
                            {
                                if (vehicleAnimType == VehicleAnimType.Low)
                                {
                                    fAnim = "low_car_prop_to_sex_p1_female";
                                    mAnim = "low_car_prop_to_sex_p1_player";
                                }
                                else
                                {
                                    fAnim = "proposition_to_sex_p1_prostitute";
                                    mAnim = "proposition_to_sex_p1_male";
                                }
                            }
                        }
                        else // 阶段1
                        {
                            if (currentAction == "口交")
                            {
                                if (vehicleAnimType == VehicleAnimType.Low)
                                {
                                    fAnim = "low_car_prop_to_bj_p2_female";
                                    mAnim = "low_car_prop_to_bj_p2_player";
                                }
                                else
                                {
                                    fAnim = "proposition_to_bj_p2_prostitute";
                                    mAnim = "proposition_to_bj_p2_male";
                                }
                            }
                            else // 性交
                            {
                                if (vehicleAnimType == VehicleAnimType.Low)
                                {
                                    fAnim = "low_car_prop_to_sex_p2_female";
                                    mAnim = "low_car_prop_to_sex_p2_player";
                                }
                                else
                                {
                                    fAnim = "proposition_to_sex_p2_prostitute";
                                    mAnim = "proposition_to_sex_p2_male";
                                }
                            }
                        }

                        // 重新开始动画，标志0(播放直到结束)
                        Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fAnim,
                            8.0f, -4.0f, -1, 0, 0.0f, false, false, false);
                        Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mAnim,
                            8.0f, -4.0f, -1, driveableCar ? 32 : 0, 0.0f, false, false, false);

                        DetachDildoProp();

                        // 卖淫模式退款
                        if (!sandboxMode && lastPaidAmount > 0)
                        {
                            Game.Player.Money += lastPaidAmount;
                            ShowSubtitle("~r~已中止! ~s~退款金额: ~g~$" + lastPaidAmount, 3000);
                            lastPaidAmount = 0;
                        }
                        else
                        {
                            ShowSubtitle("~r~已中止!", 3000);
                        }

                        state = ScriptState.Idle;
                        animPhase = 0;
                        currentAction = "";
                        return;
                    }
                    // 在循环阶段(2) - 触发退出序列
                    else if (animPhase == 2)
                    {
                        // 触发结束 - 反向序列从口交回到搭讪(标志2 = 保持最后一帧)
                        int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
                        bool isFirstPerson = (camMode == 4);

                        string dict;
                        if (vehicleAnimType == VehicleAnimType.Low)
                            dict = isFirstPerson ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
                        else
                            dict = isFirstPerson ? VEH_NORM_FP_DICT : VEH_NORM_DICT;

                        string fExitP1, mExitP1;

                        if (currentAction == "口交")
                        {
                            if (vehicleAnimType == VehicleAnimType.Low)
                            {
                                fExitP1 = "low_car_bj_to_prop_p1_female";
                                mExitP1 = "low_car_bj_to_prop_p1_player";
                            }
                            else
                            {
                                fExitP1 = "bj_to_proposition_p1_prostitute";
                                mExitP1 = "bj_to_proposition_p1_male";
                            }
                        }
                        else // 性交
                        {
                            if (vehicleAnimType == VehicleAnimType.Low)
                            {
                                fExitP1 = "low_car_sex_to_prop_p1_female";
                                mExitP1 = "low_car_sex_to_prop_p1_player";
                            }
                            else
                            {
                                fExitP1 = "sex_to_proposition_p1_prostitute";
                                mExitP1 = "sex_to_proposition_p1_male";
                            }
                        }

                        Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fExitP1,
                            8.0f, -4.0f, -1, 2, 0.0f, false, false, false);
                        Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mExitP1,
                            8.0f, -4.0f, -1, driveableCar ? 34 : 2, 0.0f, false, false, false);

                        animPhase = 3; // 进入结束阶段
                        // 设置等待时间 = 现在 + 退出动画时长(毫秒)
                        float exitP1Dur = Function.Call<float>(Hash.GET_ANIM_DURATION, dict, fExitP1);
                        animWaitTime = Game.GameTime + (int)(exitP1Dur * 1000f);
                        // 不清除 currentAction - 阶段3和4需要它来获取动画名称

                        ShowSubtitle("~g~正在结束...", 2000);
                    }
                    // 在结束阶段(3, 4) - 忽略输入，让动画完成
                    else
                    {
                        // 什么都不做，等待结束动画完成
                    }
                }
                else
                {
                    // 街头模式: 在开场阶段中止退款
                    if (animPhase < 2 && !sandboxMode && lastPaidAmount > 0)
                    {
                        Game.Player.Money += lastPaidAmount;
                        ShowSubtitle("~r~已中止! ~s~退款金额: ~g~$" + lastPaidAmount, 3000);
                        lastPaidAmount = 0;
                    }
                    // 从循环结束时播放结束语音(不是中止)
                    if (animPhase >= 2) PlayFinishSounds();
                    EndAnimation();
                }
            }
        }

        // ════════════════════════════════════════════
        // 拾取(统一 — 可从车内或步行工作)
        // ════════════════════════════════════════════
        private void TryPickup(Ped player)
        {
            Ped found = FindNearestFemale(player.Position, 7f);
            if (found == null)
            {
                ShowSubtitle(sandboxMode ? "~r~附近没有女人!" : "~r~附近没有妓女!", 2000);
                return;
            }

            // 如果玩家在车里，先检查车辆是否合适
            if (player.IsInVehicle())
            {
                Vehicle car = player.CurrentVehicle;
                if (car == null || !IsSuitableVehicle(car))
                {
                    ShowSubtitle("~r~先找一辆合适的车!", 2000);
                    return;
                }
                if (car.GetPedOnSeat(VehicleSeat.Passenger) != null)
                {
                    ShowSubtitle("~r~副驾已有人!", 2000);
                    return;
                }
            }

            girl = found;
            GeneratePedPrices(girl.Handle);
            AssignHookerVoice(girl);
            girl.IsPersistent = true;
            girl.BlockPermanentEvents = true;

            if (!sandboxMode)
            {
                // ── 卖淫模式: 妓女先向玩家走来 ──
                menuLevel = MenuLevel.None; // 搭讪过程中关闭菜单
                state = ScriptState.Approaching;
                approachPhase = 0;
                jHoldStart = 0;

                // 让她走向玩家
                if (player.IsInVehicle())
                {
                    // 走向驾驶员车窗区域
                    Vector3 windowPos = player.GetOffsetPosition(new Vector3(-1.5f, 0.5f, 0f));
                    approachTargetPos = windowPos;
                    Function.Call(Hash.TASK_GO_STRAIGHT_TO_COORD, girl,
                        windowPos.X, windowPos.Y, windowPos.Z,
                        1.0f, -1, player.Heading + 90f, 0.5f);
                }
                else
                {
                    // 步行走向玩家
                    approachTargetPos = player.Position;
                    Function.Call(Hash.TASK_GO_TO_ENTITY, girl, player, -1, 1.5f, 1.0f, 0f, 0);
                }

                ShowSubtitle("~y~一个妓女正在向你走来... ~s~(~b~按住 J~s~ 可取消)", 5000);
            }
            else
            {
                // ── 沙盒模式: 立即拾取(原有行为) ──
                hasGirl = true;
                Function.Call(Hash.SET_EVERYONE_IGNORE_PLAYER, Game.Player, true);

                if (player.IsInVehicle())
                {
                    girl.Task.EnterVehicle(player.CurrentVehicle, VehicleSeat.Passenger);
                    playerWasInVehicle = true;
                }
                else
                {
                    float dist = girl.Position.DistanceTo(player.Position);
                    float speed = (dist > 7f) ? 3f : 1f;
                    Function.Call(Hash.TASK_FOLLOW_TO_OFFSET_OF_ENTITY,
                        girl, player, 0f, -1f, 0f, speed, -1, 1.5f, true);
                    playerWasInVehicle = false;
                }

                ShowSubtitle("~g~找到女人! 现在可以选择服务!", 4000);
            }
        }

        // ═════════════════
        // 搭讪状态
        // ═════════════════
        private void HandleApproachingState(Ped player)
        {
            if (girl == null || !girl.Exists() || !girl.IsAlive)
            {
                FullReset();
                return;
            }

            // 到目标的距离(阶段0到达检查 — 车内时使用车窗位置)
            float distToTarget = player.IsInVehicle()
                ? girl.Position.DistanceTo(approachTargetPos)
                : girl.Position.DistanceTo(player.Position);

            // 到玩家的距离(所有退出检查 — 始终测量到实际玩家)
            float dist = girl.Position.DistanceTo(player.Position);

            // ── 按住 J 取消(仅在她还在走路/播放开场时) ──
            if (approachPhase <= 1)
            {
                if (Game.IsKeyPressed(Keys.J))
                {
                    if (jHoldStart == 0) jHoldStart = Game.GameTime;
                    int held = Game.GameTime - jHoldStart;
                    float pct = Math.Min(held / 600f, 1f);
                    ShowSubtitle("~r~正在取消... [" + (int)(pct * 100) + "%]", 100);
                    if (held >= 600)
                    {
                        ShowSubtitle("~r~已取消!", 2000);
                        FullReset();
                        return;
                    }
                }
                else
                {
                    jHoldStart = 0;
                }
            }

            // 阶段0: 走向玩家
            if (approachPhase == 0)
            {
                // 玩家走/开车离开 — 静默重置(无动画，她只是在走)
                if (dist > 10f)
                {
                    FullReset();
                    return;
                }

                float arrivalDist = player.IsInVehicle() ? 0.8f : 1.7f;
                if (distToTarget < arrivalDist)
                {
                    // 停止走路，面对玩家
                    girl.Task.ClearAll();
                    // 计算面向玩家的方向 — 用于所有搭讪动画
                    approachHeading = (player.Position - girl.Position).ToHeading();
                    girl.Heading = approachHeading;

                    // 选择字典(缓存，保持风格一致)
                    int girlHandle = girl.Handle;
                    if (!approachDictCache.TryGetValue(girlHandle, out approachDict))
                    {
                        approachDict = HOOKER_APPROACH_DICTS[rng.Next(HOOKER_APPROACH_DICTS.Length)];
                        approachDictCache[girlHandle] = approachDict;
                    }
                    if (!RequestAnimDict(approachDict)) { FullReset(); return; }

                    // 播放招揽语音
                    AssignHookerVoice(girl);
                    PlayPedSpeech(girl, "SOLICIT_GENERIC");

                    // 播放 idle_intro — 使用 ANIM_ADVANCED 固定面向车辆
                    Vector3 gp = girl.Position;
                    Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                        approachDict, "idle_intro",
                        gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                        8.0f, -4.0f, -1, 2, 0.0f, 2, 0);

                    float introDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_intro");
                    approachAnimWait = Game.GameTime + (int)(introDur * 1000f);
                    approachPhase = 1;
                }
            }
            // 阶段1: idle_intro 播放中 → 然后进入 idle_wait
            else if (approachPhase == 1)
            {
                if (Game.GameTime >= approachAnimWait)
                {
                    // 开场结束 — 开始 idle_wait 循环
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_wait",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 1, 0.0f, 2, 0);
                    } // 标志1 = 循环

                    // 安排第一次性感姿势打断
                    approachSexySwapTime = Game.GameTime + rng.Next(4000, 8000);
                    approachDecisionTimer = Game.GameTime + 45000; // 45秒耐心
                    approachPhase = 2;
                }
            }
            // 阶段2: idle_wait (循环) — 接受/拒绝，偶尔性感姿势打断
            else if (approachPhase == 2)
            {
                // 玩家走/开车离开 — 播放 idle_outro 然后重置
                if (dist > 10f)
                {
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_outro",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 0, 0.0f, 2, 0);
                    }
                    float outroDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_outro");
                    approachAnimWait = Game.GameTime + (int)(outroDur * 1000f);
                    approachPhase = 7; // 结束然后重置
                    return;
                }

                // 45秒耐心耗尽 — 她自行拒绝
                if (Game.GameTime >= approachDecisionTimer)
                {
                    Function.Call(Hash.STOP_CURRENT_PLAYING_AMBIENT_SPEECH, girl);
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_reject",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 2, 0.0f, 2, 0);
                    }
                    float rejectDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_reject");
                    approachAnimWait = Game.GameTime + (int)(rejectDur * 1000f);
                    approachPhase = 4;
                    ShowSubtitle("~r~她等得不耐烦了!", 2000);
                    return;
                }

                DrawTextOnScreen("~g~[小键盘5]~s~ 接受   ~r~[小键盘0]~s~ 拒绝", 0.05f, 0.05f);

                // 偶尔用性感姿势打断，然后回到 idle_wait
                if (Game.GameTime >= approachSexySwapTime)
                {
                    string sexyAnim = HOOKER_SEXY_ANIMS[rng.Next(HOOKER_SEXY_ANIMS.Length)];
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, sexyAnim,
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 2, 0.0f, 2, 0);
                    } // 标志2 = 保持最后一帧

                    float sexyDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, sexyAnim);
                    approachAnimWait = Game.GameTime + (int)(sexyDur * 1000f);
                    approachPhase = 6; // 性感姿势播放中
                }

                if (Game.IsKeyPressed(Keys.NumPad5))
                {
                    // ── 接受: 播放 idle_outro 然后过渡 ──
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_outro",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 0, 0.0f, 2, 0);
                    }

                    float outroDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_outro");
                    approachAnimWait = Game.GameTime + (int)(outroDur * 1000f);
                    approachPhase = 3;
                }
                else if (Game.IsKeyPressed(Keys.NumPad0))
                {
                    // ── 拒绝: 播放 idle_reject 然后 reject_outro ──
                    Function.Call(Hash.STOP_CURRENT_PLAYING_AMBIENT_SPEECH, girl);
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_reject",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 2, 0.0f, 2, 0);
                    }

                    float rejectDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_reject");
                    approachAnimWait = Game.GameTime + (int)(rejectDur * 1000f);
                    approachPhase = 4;
                    ShowSubtitle("~r~已拒绝!", 2000);
                }
            }
            // 阶段3: idle_outro (已接受) — 等待动画完成然后过渡到 hasGirl
            else if (approachPhase == 3)
            {
                // 玩家在她结束前离开
                if (dist > 15f)
                {
                    FullReset();
                    return;
                }

                if (Game.GameTime >= approachAnimWait)
                {
                    girl.Task.ClearAll();
                    hasGirl = true;
                    Function.Call(Hash.SET_EVERYONE_IGNORE_PLAYER, Game.Player, true);

                    if (player.IsInVehicle())
                    {
                        girl.Task.EnterVehicle(player.CurrentVehicle, VehicleSeat.Passenger);
                        playerWasInVehicle = true;
                    }
                    else
                    {
                        Function.Call(Hash.TASK_FOLLOW_TO_OFFSET_OF_ENTITY,
                            girl, player, 0f, -1f, 0f, 1f, -1, 1.5f, true);
                        playerWasInVehicle = false;
                    }

                    state = ScriptState.Idle;
                    menuLevel = MenuLevel.Main;
                    menuIndex = 0;
                    keyCooldown = KEY_COOLDOWN_FRAMES;
                    ShowSubtitle("~g~已接受! 选择服务吧!", 3000);
                }
            }
            // 阶段4: idle_reject — 等待然后播放 reject_outro
            else if (approachPhase == 4)
            {
                if (Game.GameTime >= approachAnimWait)
                {
                    // 使用普通的 TASK_PLAY_ANIM — idle_reject 可能已让她转身，
                    // 所以 reject_outro 应该从她当前方向继续(无回弹)
                    Function.Call(Hash.TASK_PLAY_ANIM, girl,
                        approachDict, "reject_outro",
                        8.0f, -4.0f, -1, 0, 0.0f, false, false, false);

                    float roaDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "reject_outro");
                    approachAnimWait = Game.GameTime + (int)(roaDur * 1000f);
                    approachPhase = 5;
                }
            }
            // 阶段5: reject_outro — 等待然后完全重置
            else if (approachPhase == 5)
            {
                if (Game.GameTime >= approachAnimWait)
                {
                    FullReset();
                }
            }
            // 阶段7: idle_outro (玩家离开) — 等待然后完全重置
            else if (approachPhase == 7)
            {
                if (Game.GameTime >= approachAnimWait)
                {
                    FullReset();
                }
            }
            // 阶段6: 性感姿势(idle_a/b/c/d)播放中 — 完成后回到 idle_wait
            else if (approachPhase == 6)
            {
                // 玩家走/开车离开 — 播放 idle_outro 然后重置
                if (dist > 10f)
                {
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_outro",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 0, 0.0f, 2, 0);
                    }
                    float outroDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_outro");
                    approachAnimWait = Game.GameTime + (int)(outroDur * 1000f);
                    approachPhase = 7; // 结束然后重置
                    return;
                }

                // 45秒耐心耗尽 — 她自行拒绝
                if (Game.GameTime >= approachDecisionTimer)
                {
                    Function.Call(Hash.STOP_CURRENT_PLAYING_AMBIENT_SPEECH, girl);
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_reject",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 2, 0.0f, 2, 0);
                    }
                    float rejectDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_reject");
                    approachAnimWait = Game.GameTime + (int)(rejectDur * 1000f);
                    approachPhase = 4;
                    ShowSubtitle("~r~她等得不耐烦了!", 2000);
                    return;
                }

                DrawTextOnScreen("~g~[小键盘5]~s~ 接受   ~r~[小键盘0]~s~ 拒绝", 0.05f, 0.05f);

                if (Game.GameTime >= approachAnimWait)
                {
                    // 回到 idle_wait 循环
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_wait",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 1, 0.0f, 2, 0);
                    } // 标志1 = 循环

                    // 安排下次性感姿势打断
                    approachSexySwapTime = Game.GameTime + rng.Next(4000, 8000);
                    approachPhase = 2;
                }

                // 性感姿势期间仍允许接受/拒绝
                if (Game.IsKeyPressed(Keys.NumPad5))
                {
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_outro",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 0, 0.0f, 2, 0);
                    }

                    float outroDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_outro");
                    approachAnimWait = Game.GameTime + (int)(outroDur * 1000f);
                    approachPhase = 3;
                }
                else if (Game.IsKeyPressed(Keys.NumPad0))
                {
                    Function.Call(Hash.STOP_CURRENT_PLAYING_AMBIENT_SPEECH, girl);
                    {
                        Vector3 gp = girl.Position;
                        Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, girl,
                            approachDict, "idle_reject",
                            gp.X, gp.Y, gp.Z, 0.0f, 0.0f, approachHeading,
                            8.0f, -4.0f, -1, 2, 0.0f, 2, 0);
                    }

                    float rejectDur = Function.Call<float>(Hash.GET_ANIM_DURATION, approachDict, "idle_reject");
                    approachAnimWait = Game.GameTime + (int)(rejectDur * 1000f);
                    approachPhase = 4;
                    ShowSubtitle("~r~已拒绝!", 2000);
                }
            }
        }

        /// <summary>检查车辆是否合适(不是摩托/船/飞机)。</summary>
        private bool IsSuitableVehicle(Vehicle car)
        {
            if (car == null) return false;
            var cls = car.ClassType;
            return cls != VehicleClass.Motorcycles &&
                   cls != VehicleClass.Cycles &&
                   cls != VehicleClass.Boats &&
                   cls != VehicleClass.Helicopters &&
                   cls != VehicleClass.Planes;
        }

        // ═══════════
        // 车内动作
        // ═══════════
        private void StartCarAction(int idx)
        {
            if (girl == null || !girl.Exists()) { FullReset(); return; }
            Ped player = Game.Player.Character;
            if (!player.IsInVehicle()) return;

            Vehicle car = player.CurrentVehicle;
            if (car == null) return;
            if (!girl.IsInVehicle() || girl.CurrentVehicle != car) return;

            // Determine vehicle animation type
            int modelHash = car.Model.Hash;
            
            // Check manual overrides first (from .cfg)
            if (overwriteLowVehicle.Contains(modelHash))
            {
                vehicleAnimType = VehicleAnimType.Low;
            }
            else if (overwriteNormalVehicle.Contains(modelHash))
            {
                vehicleAnimType = VehicleAnimType.Normal;
            }
            else
            {
                // Fallback: ClassType detection
                int classType = Function.Call<int>(Hash.GET_VEHICLE_CLASS, car);
                // Low vehicles: Coupes (3), Sports Classics (5), Sports (6), Super (7)
                if (classType == 3 || classType == 5 || classType == 6 || classType == 7)
                    vehicleAnimType = VehicleAnimType.Low;
                else
                    vehicleAnimType = VehicleAnimType.Normal;
            }
            
            string dict = (vehicleAnimType == VehicleAnimType.Low) ? VEH_LOW_DICT : VEH_NORM_DICT;

            // Also preload first-person variant
            RequestAnimDict((vehicleAnimType == VehicleAnimType.Low) ? VEH_LOW_FP_DICT : VEH_NORM_FP_DICT);

            if (!RequestAnimDict(dict))
            {
                ShowSubtitle("~r~FAILED TO LOAD ANIMATIONS!", 2000);
                return;
            }

            // Setup
            Function.Call(Hash.SET_EVERYONE_IGNORE_PLAYER, Game.Player, true);

            // Store loop anim names (for phase 2) based on action
            string fIntro = "", mIntro = "";
            
            if (idx == 0) // Blowjob
            {
                if (vehicleAnimType == VehicleAnimType.Low)
                {
                    currentFemaleAnim = "low_car_bj_loop_female";
                    currentMaleAnim = "low_car_bj_loop_player";
                    fIntro = "low_car_prop_to_bj_p1_female";
                    mIntro = "low_car_prop_to_bj_p1_player";
                }
                else
                {
                    currentFemaleAnim = "bj_loop_prostitute";
                    currentMaleAnim = "bj_loop_male";
                    fIntro = "proposition_to_bj_p1_prostitute";
                    mIntro = "proposition_to_bj_p1_male";
                }
                currentAction = "blowjob";
                healPlayer = true; healGirl = false; healRate = 0.7f;
            }
            else if (idx == 1) // Sex
            {
                if (vehicleAnimType == VehicleAnimType.Low)
                {
                    currentFemaleAnim = "low_car_sex_loop_female";
                    currentMaleAnim = "low_car_sex_loop_player";
                    fIntro = "low_car_prop_to_sex_p1_female";
                    mIntro = "low_car_prop_to_sex_p1_player";
                }
                else
                {
                    currentFemaleAnim = "sex_loop_prostitute";
                    currentMaleAnim = "sex_loop_male";
                    fIntro = "proposition_to_sex_p1_prostitute";
                    mIntro = "proposition_to_sex_p1_male";
                }
                currentAction = "sex";
                healPlayer = true; healGirl = true; healRate = 0.5f;
            }
            
            currentFemaleDict = dict;
            currentMaleDict   = dict;

            // Start INTRO animations (flag 2 = hold last frame, no reset)
            
            Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fIntro,
                8.0f, -4.0f, -1, 2, 0.0f, false, false, false);
            Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mIntro,
                8.0f, -4.0f, -1, driveableCar ? 34 : 2, 0.0f, false, false, false);

            // Lock the animation task NOW (after it's been given)
            Function.Call(Hash.SET_PED_KEEP_TASK, girl, true);

            AttachDildoProp(player);

            state = ScriptState.Animating;
            animPhase = 0; // Start with intro
            // Set wait time = now + animation duration (ms) using GET_ANIM_DURATION
            float introDuration = Function.Call<float>(Hash.GET_ANIM_DURATION, dict, fIntro);
            animWaitTime = Game.GameTime + (int)(introDuration * 1000f);
            lastVoiceTime = Game.GameTime;

            ShowSubtitle("~g~STARTING... ~s~(~y~PRESS J TO ABORT~s~)", 2000);
        }

        // ══════════════
        // STREET ACTIONS
        // ══════════════
        private void StartStreetAction(int idx)
        {
            if (girl == null || !girl.Exists()) { FullReset(); return; }
            Ped player = Game.Player.Character;
            if (player.IsInVehicle()) return;

            // Get animation data for this action
            string mDict, mAnim, fDict, fAnim;
            Vector3 offset;
            float headingOff;
            bool isSitting;
            float zOffset;
            float rotX;
            GetStreetAnimData(idx, out mDict, out mAnim, out fDict, out fAnim, out offset, out headingOff, out isSitting, out zOffset, out rotX);

            // Request anim dictionaries
            if (!RequestAnimDict(mDict)) { ShowSubtitle("~r~FAILED TO LOAD ANIMATIONS!", 2000); return; }
            if (mDict != fDict && !RequestAnimDict(fDict)) { ShowSubtitle("~r~FAILED TO LOAD ANIMATIONS!", 2000); return; }

            currentMaleDict   = mDict;
            currentMaleAnim   = mAnim;
            currentFemaleDict = fDict;
            currentFemaleAnim = fAnim;
            currentAction = (idx == 0) ? "kissing" : (idx >= 2 && idx <= 4) ? "blowjob" : "sex";

            // Healing rules per action type
            if (idx == 0) // Kissing: no healing
            { healPlayer = false; healGirl = false; healRate = 0.0f; }
            else if (idx == 1) // Facesitting: NPC only
            { healPlayer = false; healGirl = true; healRate = 0.7f; }
            else if (idx >= 2 && idx <= 4) // BJs: player only
            { healPlayer = true; healGirl = false; healRate = 0.7f; }
            else // All other sex: both, slowest
            { healPlayer = true; healGirl = true; healRate = 0.5f; }

            // Setup
            // 1. Disable collision between the two peds
            Function.Call(Hash.SET_ENTITY_NO_COLLISION_ENTITY, girl, player, false);

            Vector3 girlPos = player.GetOffsetPosition(offset);

            // 2. For sitting anims: disable collision and sink peds underground.
            //    The car-seat animation lifts them back up to ground level visually.
            //    Same trick used in old GTA IV HotCoffee (zOffset = -2.12f etc.)
            if (isSitting)
            {
                Function.Call(Hash.SET_ENTITY_COLLISION, player, false, false);
                Function.Call(Hash.SET_ENTITY_COLLISION, girl, false, false);
            }

            Vector3 playerPos = new Vector3(player.Position.X, player.Position.Y, player.Position.Z + zOffset);
            Vector3 girlFinal = new Vector3(girlPos.X, girlPos.Y, girlPos.Z + zOffset);

            Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, player,
                playerPos.X, playerPos.Y, playerPos.Z, false, false, false);
            Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, girl,
                girlFinal.X, girlFinal.Y, girlFinal.Z, false, false, false);
            girl.Heading = player.Heading + headingOff;

            // 3. Freeze both peds at their (possibly sunken) positions
            player.IsPositionFrozen = true;
            girl.IsPositionFrozen = true;

            // 4. Make everyone ignore
            Function.Call(Hash.SET_EVERYONE_IGNORE_PLAYER, Game.Player, true);

            Wait(100);

            // 5. Play animations - flag 9 = AF_LOOPING(1) + AF_NOT_INTERRUPTABLE(8)
            float startPhase = (mDict == "trevor_1_int-13") ? 0.205f : 0.0f;
            if (rotX != 0.0f)
            {
                // Use TASK_PLAY_ANIM_ADVANCED for player to apply pitch rotation
                Vector3 pp = player.Position;
                Function.Call(Hash.TASK_PLAY_ANIM_ADVANCED, player, mDict, mAnim,
                    pp.X, pp.Y, pp.Z,
                    rotX, 0.0f, player.Heading,
                    8.0f, -4.0f, -1, 9, startPhase, 2, 0);
            }
            else
            {
                Function.Call(Hash.TASK_PLAY_ANIM, player, mDict, mAnim,
                    8.0f, -4.0f, -1, 9, startPhase, false, false, false);
            }
            Function.Call(Hash.TASK_PLAY_ANIM, girl, fDict, fAnim,
                8.0f, -4.0f, -1, 9, startPhase, false, false, false);

            // Lock the animation task NOW (after it's been given, not before)
            Function.Call(Hash.SET_PED_KEEP_TASK, girl, true);

            streetActionIdx = idx;
            if (currentAction != "kissing" && idx != 1) AttachDildoProp(player);

            Wait(200);

            // Verify at least one started
            bool mPlaying = Function.Call<bool>(Hash.IS_ENTITY_PLAYING_ANIM, player, mDict, mAnim, 3);
            bool fPlaying = Function.Call<bool>(Hash.IS_ENTITY_PLAYING_ANIM, girl, fDict, fAnim, 3);
            if (!mPlaying && !fPlaying)
            {
                ShowSubtitle("~r~ANIMATION FAILED! TRY AGAIN!", 2000);
                EndAnimation();
                return;
            }

            state = ScriptState.Animating;
            animPhase = 2;
            lastVoiceTime = Game.GameTime;
        }

        /// <summary>
        /// Returns animation data for each street action.
        /// </summary>
        private void GetStreetAnimData(int idx, out string mDict, out string mAnim,
            out string fDict, out string fAnim, out Vector3 offset, out float heading,
            out bool isSitting, out float zOffset, out float rotX)
        {
            switch (idx)
            {
                case 0: // Kissing (mp_ped_interaction)
                default:
                    mDict = "mp_ped_interaction";
                    mAnim = "kisses_guy_a";
                    fDict = "mp_ped_interaction";
                    fAnim = "kisses_guy_a";
                    offset = new Vector3(0.0f, 1.29f, 0.07f);
                    heading = 180f;
                    isSitting = false;
                    zOffset = 0.0f;
                    rotX = 0.0f;
                    break;
                case 1: // Facesitting (saveveniceb@ + sexnorm_veh)
                    mDict = "saveveniceb@";
                    mAnim = "t_sleep_loop_veniceb";
                    fDict = "mini@prostitutes@sexnorm_veh";
                    fAnim = "sex_loop_prostitute";
                    offset = new Vector3(0.73f, -0.77f, -0.3f);
                    heading = 0f;
                    isSitting = true;
                    zOffset = -0.59f;
                    rotX = 0.0f;
                    break;
                case 2: // Standing Blowjob (misscarsteal2pimpsex)
                    mDict = "misscarsteal2pimpsex";
                    mAnim = "pimpsex_punter";
                    fDict = "misscarsteal2pimpsex";
                    fAnim = "pimpsex_hooker";
                    offset = new Vector3(0.0f, 0.5f, 0.0f);
                    heading = 180f;
                    isSitting = false;
                    zOffset = 0.0f;
                    rotX = 0.0f;
                    break;
                case 3: // Sitting Blowjob (mini@prostitutes@sexnorm_veh)
                    mDict = "mini@prostitutes@sexnorm_veh";
                    mAnim = "bj_loop_male";
                    fDict = "mini@prostitutes@sexnorm_veh";
                    fAnim = "bj_loop_prostitute";
                    offset = new Vector3(0.78f, 0.0f, -0.02f);
                    heading = 0f;
                    isSitting = true;
                    zOffset = -0.87f;
                    rotX = 5.0f;
                    break;
                case 4: // Laying Blowjob (saveveniceb@ + sexnorm_veh)
                    mDict = "saveveniceb@";
                    mAnim = "t_sleep_loop_veniceb";
                    fDict = "mini@prostitutes@sexnorm_veh";
                    fAnim = "bj_loop_prostitute";
                    offset = new Vector3(0.17f, 0.8f, -0.37f);
                    heading = 90f;
                    isSitting = true;
                    zOffset = -0.59f;
                    rotX = 0.0f;
                    break;
                case 5: // Wall Banger (misscarsteal2pimpsex)
                    mDict = "misscarsteal2pimpsex";
                    mAnim = "shagloop_pimp";
                    fDict = "misscarsteal2pimpsex";
                    fAnim = "shagloop_hooker";
                    offset = new Vector3(0.02f, 0.36f, 0.088f);
                    heading = 190f;
                    isSitting = true;
                    zOffset = -0.15f;
                    rotX = 0.0f;
                    break;
                case 6: // Sitting Cowgirl (mini@prostitutes@sexnorm_veh)
                    mDict = "mini@prostitutes@sexnorm_veh";
                    mAnim = "sex_loop_male";
                    fDict = "mini@prostitutes@sexnorm_veh";
                    fAnim = "sex_loop_prostitute";
                    offset = new Vector3(0.85f, -0.01f, -0.02f);
                    heading = 0f;
                    isSitting = true;
                    zOffset = -0.87f;
                    rotX = 5.0f;
                    break;
                case 7: // Reverse Cowgirl (mini@prostitutes@sexnorm_veh)
                    mDict = "mini@prostitutes@sexnorm_veh";
                    mAnim = "sex_loop_male";
                    fDict = "mini@prostitutes@sexnorm_veh";
                    fAnim = "sex_loop_prostitute";
                    offset = new Vector3(-0.83f, 0.4f, 0.02f);
                    heading = 180f;
                    isSitting = true;
                    zOffset = -0.87f;
                    rotX = 5.0f;
                    break;
                case 8: // Laying Cowgirl (random@drunk_driver_2)
                    mDict = "random@drunk_driver_2";
                    mAnim = "cardrunksex_loop_m";
                    fDict = "random@drunk_driver_2";
                    fAnim = "cardrunksex_loop_f";
                    offset = new Vector3(-0.65f, 0.0f, -0.02f);
                    heading = 0f;
                    isSitting = true;
                    zOffset = -0.95f;
                    rotX = 0.0f;
                    break;
                case 9: // Laying Reversed (random@drunk_driver_2)
                    mDict = "random@drunk_driver_2";
                    mAnim = "cardrunksex_loop_m";
                    fDict = "random@drunk_driver_2";
                    fAnim = "cardrunksex_loop_f";
                    offset = new Vector3(-0.35f, 0.15f, -0.02f);
                    heading = 180f;
                    isSitting = true;
                    zOffset = -0.95f;
                    rotX = 0.0f;
                    break;
                case 10: // Doggy Style (rcmpaparazzo_2)
                    mDict = "rcmpaparazzo_2";
                    mAnim = "shag_loop_a";
                    fDict = "rcmpaparazzo_2";
                    fAnim = "shag_loop_poppy";
                    offset = new Vector3(-0.03f, 0.3f, -0.1f);
                    heading = 0f;
                    isSitting = false;
                    zOffset = 0.0f;
                    rotX = 0.0f;
                    break;
                case 11: // Rough Doggy Style (trevor_1_int-13)
                    mDict = "trevor_1_int-13";
                    mAnim = "player_two_dual-13";
                    fDict = "trevor_1_int-13";
                    fAnim = "cs_ashley_dual-13";
                    offset = new Vector3(-0.04f, 0.33f, -0.11f);
                    heading = 13f;
                    isSitting = false;
                    zOffset = 0.0f;
                    rotX = 0.0f;
                    break;
            }
        }

        // ═════════════════════════════════════
        // CAR ANIMATION TICK (runs every frame)
        // ═════════════════════════════════════
        private void RunCarAnimation(Ped player)
        {
            // Check if player is in first person
            int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
            bool isFirstPerson = (camMode == 4);
            
            string dict;
            if (vehicleAnimType == VehicleAnimType.Low)
                dict = isFirstPerson ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
            else
                dict = isFirstPerson ? VEH_NORM_FP_DICT : VEH_NORM_DICT;
            
            if (animPhase == 0) // INTRO: proposition_to_[action]_p1
            {
                if (animWaitTime <= Game.GameTime)
                {
                    // Move to p2 (flag 2 = hold last frame)
                    string fP2, mP2;
                    
                    if (currentAction == "blowjob")
                    {
                        if (vehicleAnimType == VehicleAnimType.Low)
                        {
                            fP2 = "low_car_prop_to_bj_p2_female";
                            mP2 = "low_car_prop_to_bj_p2_player";
                        }
                        else
                        {
                            fP2 = "proposition_to_bj_p2_prostitute";
                            mP2 = "proposition_to_bj_p2_male";
                        }
                    }
                    else // sex
                    {
                        if (vehicleAnimType == VehicleAnimType.Low)
                        {
                            fP2 = "low_car_prop_to_sex_p2_female";
                            mP2 = "low_car_prop_to_sex_p2_player";
                        }
                        else
                        {
                            fP2 = "proposition_to_sex_p2_prostitute";
                            mP2 = "proposition_to_sex_p2_male";
                        }
                    }
                    
                    Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fP2,
                        8.0f, -4.0f, -1, 2, 0.0f, false, false, false);
                    Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mP2,
                        8.0f, -4.0f, -1, driveableCar ? 34 : 2, 0.0f, false, false, false);
                    float p2Dur = Function.Call<float>(Hash.GET_ANIM_DURATION, dict, fP2);
                    animWaitTime = Game.GameTime + (int)(p2Dur * 1000f);
                    animPhase = 1;
                }
            }
            else if (animPhase == 1) // INTRO: proposition_to_[action]_p2
            {
                if (animWaitTime <= Game.GameTime)
                {
                    // Move to LOOP
                    Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, currentFemaleAnim,
                        8.0f, -4.0f, -1, 1, 0.0f, false, false, false);
                    Function.Call(Hash.TASK_PLAY_ANIM, player, dict, currentMaleAnim,
                        8.0f, -4.0f, -1, driveableCar ? 33 : 1, 0.0f, false, false, false);
                    animPhase = 2;
                    lastShakeTime = Game.GameTime + 500;
                }
            }
            else if (animPhase == 2) // LOOP - shake car during sex
            {
                if (currentAction == "sex" && animSpeed >= 0.75f && player.IsInVehicle())
                {
                    Vehicle car = player.CurrentVehicle;
                    if (car != null)
                    {
                        int now = Game.GameTime;
                        int shakeInterval = (int)(670f / animSpeed); // Faster anim = faster bounce
                        if (now - lastShakeTime >= shakeInterval)
                        {
                            float force = 0.65f * Math.Min(animSpeed, 2.0f); // Stronger bounce, capped at 2x
                            Vector3 down = -force * car.UpVector;
                            car.ApplyForce(down, Vector3.Zero, (ForceType)3);
                            lastShakeTime = now;
                        }
                    }
                }
            }
            else if (animPhase == 3) // OUTRO: [action]_to_proposition_p1
            {
                if (animWaitTime <= Game.GameTime)
                {
                    // Move to p2 exit stage (flag 0 = play once, no hold)
                    string fP2Exit, mP2Exit;
                    
                    if (currentAction == "blowjob")
                    {
                        if (vehicleAnimType == VehicleAnimType.Low)
                        {
                            fP2Exit = "low_car_bj_to_prop_p2_female";
                            mP2Exit = "low_car_bj_to_prop_p2_player";
                        }
                        else
                        {
                            fP2Exit = "bj_to_proposition_p2_prostitute";
                            mP2Exit = "bj_to_proposition_p2_male";
                        }
                    }
                    else // sex
                    {
                        if (vehicleAnimType == VehicleAnimType.Low)
                        {
                            fP2Exit = "low_car_sex_to_prop_p2_female";
                            mP2Exit = "low_car_sex_to_prop_p2_player";
                        }
                        else
                        {
                            fP2Exit = "sex_to_proposition_p2_prostitute";
                            mP2Exit = "sex_to_proposition_p2_male";
                        }
                    }
                    
                    Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fP2Exit,
                        8.0f, -4.0f, -1, 0, 0.0f, false, false, false);
                    Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mP2Exit,
                        8.0f, -4.0f, -1, driveableCar ? 32 : 0, 0.0f, false, false, false);

                    float p2ExitDur = Function.Call<float>(Hash.GET_ANIM_DURATION, dict, fP2Exit);
                    animWaitTime = Game.GameTime + (int)(p2ExitDur * 1000f);
                    animPhase = 4;
                }
            }
            else if (animPhase == 4) // OUTRO: [action]_to_proposition_p2
            {
                if (animWaitTime <= Game.GameTime)
                {
                    PlayFinishSounds();
                    FinishCarServiceAndReopen();
                }
            }
        }

        // ════════════════════
        // CAR PROPOSITION POSE
        // ════════════════════

        /// <summary>Start the into_proposition anim when opening Services menu in a car.</summary>
        private void EnterCarProposition(Ped player)
        {
            if (!player.IsInVehicle()) return;
            Vehicle car = player.CurrentVehicle;
            if (car == null) return;

            // Determine vehicle animation type
            int modelHash = car.Model.Hash;
            if (overwriteLowVehicle.Contains(modelHash))
                vehicleAnimType = VehicleAnimType.Low;
            else if (overwriteNormalVehicle.Contains(modelHash))
                vehicleAnimType = VehicleAnimType.Normal;
            else
            {
                int classType = Function.Call<int>(Hash.GET_VEHICLE_CLASS, car);
                if (classType == 3 || classType == 5 || classType == 6 || classType == 7)
                    vehicleAnimType = VehicleAnimType.Low;
                else
                    vehicleAnimType = VehicleAnimType.Normal;
            }

            // Get dict (check first person)
            int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
            bool isFirstPerson = (camMode == 4);
            string dict;
            if (vehicleAnimType == VehicleAnimType.Low)
                dict = isFirstPerson ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
            else
                dict = isFirstPerson ? VEH_NORM_FP_DICT : VEH_NORM_DICT;

            if (!RequestAnimDict(dict)) return;
            // Preload all dict variants
            RequestAnimDict((vehicleAnimType == VehicleAnimType.Low) ? VEH_LOW_FP_DICT : VEH_NORM_FP_DICT);
            RequestAnimDict((vehicleAnimType == VehicleAnimType.Low) ? VEH_LOW_DICT : VEH_NORM_DICT);

            // Get enter anim names
            string fEnter, mEnter;
            if (vehicleAnimType == VehicleAnimType.Low)
            { fEnter = "low_car_sit_to_prop_female"; mEnter = "low_car_sit_to_prop_player"; }
            else
            { fEnter = "into_proposition_prostitute"; mEnter = "into_proposition_male"; }

            // Play enter anims (flag 2 = hold last frame)
            Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fEnter,
                8.0f, -4.0f, -1, 2, 0.0f, false, false, false);
            Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mEnter,
                8.0f, -4.0f, -1, driveableCar ? 34 : 2, 0.0f, false, false, false);

            float enterDur = Function.Call<float>(Hash.GET_ANIM_DURATION, dict, fEnter);
            carPropActive = true;
            carPropPhase = 0;
            carPropWaitTime = Game.GameTime + Math.Max((int)(enterDur * 1000f), 1500);
        }

        /// <summary>Play the exit animation from proposition pose back to sitting.</summary>
        private void ExitCarProposition(Ped player)
        {
            if (!carPropActive) return;

            int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
            bool isFirstPerson = (camMode == 4);
            string dict;
            if (vehicleAnimType == VehicleAnimType.Low)
                dict = isFirstPerson ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
            else
                dict = isFirstPerson ? VEH_NORM_FP_DICT : VEH_NORM_DICT;

            string fExit, mExit;
            if (vehicleAnimType == VehicleAnimType.Low)
            { fExit = "low_car_prop_to_sit_female"; mExit = "low_car_prop_to_sit_player"; }
            else
            { fExit = "prop_to_sit_prostitute"; mExit = "prop_to_sit_male"; }

            Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fExit,
                8.0f, -4.0f, -1, 0, 0.0f, false, false, false);
            Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mExit,
                8.0f, -4.0f, -1, driveableCar ? 32 : 0, 0.0f, false, false, false);

            float exitDur = Function.Call<float>(Hash.GET_ANIM_DURATION, dict, fExit);
            carPropPhase = 2;
            carPropWaitTime = Game.GameTime + (int)(exitDur * 1000f);
        }

        /// <summary>After a car service outro finishes, go back to proposition loop and reopen services.</summary>
        private void FinishCarServiceAndReopen()
        {
            Ped player = Game.Player.Character;

            // Partial cleanup (don't clear anims — we're transitioning back to proposition loop)
            DetachDildoProp();

            // Finish heal boost
            if (healPlayer)
                player.Health = Math.Min(player.Health + FINISH_HEAL, player.MaxHealth);
            if (healGirl && girl != null && girl.Exists())
                girl.Health = Math.Min(girl.Health + FINISH_HEAL, girl.MaxHealth);

            // Re-enable controls that were disabled during animation
            Function.Call(Hash.SET_PLAYER_CAN_DO_DRIVE_BY, Game.Player, true);

            // Reset animation state
            animPhase = 0;
            animSpeed = 1.0f;
            speedCooldown = 0;
            healPlayer = false;
            healGirl = false;
            healRate = 1.0f;
            streetActionIdx = -1;
            currentAction = "";
            lastPaidAmount = 0;

            // Start proposition loop (we're already in proposition pose from the outro)
            int camMode = Function.Call<int>(Hash.GET_FOLLOW_PED_CAM_VIEW_MODE);
            bool isFirstPerson = (camMode == 4);
            string dict;
            if (vehicleAnimType == VehicleAnimType.Low)
                dict = isFirstPerson ? VEH_LOW_FP_DICT : VEH_LOW_DICT;
            else
                dict = isFirstPerson ? VEH_NORM_FP_DICT : VEH_NORM_DICT;

            string fLoop, mLoop;
            if (vehicleAnimType == VehicleAnimType.Low)
            { fLoop = "low_car_prop_loop_female"; mLoop = "low_car_prop_loop_player"; }
            else
            { fLoop = "proposition_loop_prostitute"; mLoop = "proposition_loop_male"; }

            Function.Call(Hash.TASK_PLAY_ANIM, girl, dict, fLoop,
                8.0f, -4.0f, -1, 1, 0.0f, false, false, false);
            Function.Call(Hash.TASK_PLAY_ANIM, player, dict, mLoop,
                8.0f, -4.0f, -1, driveableCar ? 33 : 1, 0.0f, false, false, false);

            // Set proposition state
            carPropActive = true;
            carPropPhase = 1; // Already looping

            // Switch back to idle and reopen services menu
            state = ScriptState.Idle;
            menuLevel = MenuLevel.Services;
            menuIndex = 0;
            negotiateMode = false;
            keyCooldown = KEY_COOLDOWN_FRAMES;

            ShowSubtitle("~g~DONE!", 3000);
        }

        // ═════════════
        // END / CLEANUP
        // ═════════════
        private void EndAnimation()
        {
            Ped player = Game.Player.Character;

            // Clear animations
            if (mode == Mode.Street)
            {
                // Matches the old HotCoffee End() exactly:
                //   Player.FreezePosition = false
                //   hotCoffeePed.FreezePosition = false
                //   hotCoffeePed.SetNoCollision(Player, false)
                //   hotCoffeePed.Task.ClearAll()
                //   Player.Task.ClearAll()
                player.IsPositionFrozen = false;
                Function.Call(Hash.SET_ENTITY_COLLISION, player, true, true);
                player.Task.ClearAll();

                if (girl != null && girl.Exists())
                {
                    girl.IsPositionFrozen = false;
                    Function.Call(Hash.SET_ENTITY_COLLISION, girl, true, true);
                    Function.Call(Hash.SET_ENTITY_NO_COLLISION_ENTITY, girl, player, true);
                    // Release task lock so ClearAll works, then re-lock for idle
                    Function.Call(Hash.SET_PED_KEEP_TASK, girl, false);
                    girl.Task.ClearAll();
                    Function.Call(Hash.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, girl, true);
                    // Resume following the player
                    float dist = girl.Position.DistanceTo(player.Position);
                    float speed = (dist > 7f) ? 3f : 1f;
                    Function.Call(Hash.TASK_FOLLOW_TO_OFFSET_OF_ENTITY,
                        girl, player, 0f, -1f, 0f, speed, -1, 1.5f, true);
                }
            }
            else
            {
                Function.Call(Hash.CLEAR_PED_SECONDARY_TASK, player);
                if (girl != null && girl.Exists())
                {
                    Function.Call(Hash.SET_PED_KEEP_TASK, girl, false);
                    Function.Call(Hash.CLEAR_PED_SECONDARY_TASK, girl);
                    // Re-lock after clearing task
                    Function.Call(Hash.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, girl, true);
                }
            }

            // Finish heal boost (BJ→player, facesitting→girl, sex→both)
            if (healPlayer)
                player.Health = Math.Min(player.Health + FINISH_HEAL, player.MaxHealth);
            if (healGirl && girl != null && girl.Exists())
                girl.Health = Math.Min(girl.Health + FINISH_HEAL, girl.MaxHealth);

            DetachDildoProp();

            // Re-enable everything
            Function.Call(Hash.SET_PLAYER_CAN_DO_DRIVE_BY, Game.Player, true);
            Function.Call(Hash.SET_EVERYONE_IGNORE_PLAYER, Game.Player, false);

            state = ScriptState.Idle;
            animPhase = 0;
            animSpeed = 1.0f;
            speedCooldown = 0;
            healPlayer = false;
            healGirl = false;
            healRate = 1.0f;
            streetActionIdx = -1;
            currentAction = ""; // Clear action after all animations complete
            lastPaidAmount = 0; // Service completed — no refund
            keyCooldown = KEY_COOLDOWN_FRAMES * 3; // Extra cooldown so menu can't open immediately

            ShowSubtitle("~g~DONE!", 3000);
        }

        // ═══════
        // HELPERS
        // ═══════

        /// <summary>Attach dildo prop to player's pelvis bone with per-animation offsets.</summary>
        private void AttachDildoProp(Ped player)
        {
            if (!dildoEnabled) return; // Respect toggle setting
            DetachDildoProp(); // Clean up any existing prop first

            Model mdl = new Model("prop_cs_dildo_01");
            mdl.Request(1000);
            if (!mdl.IsLoaded) return;

            dildoProp = World.CreateProp(mdl, player.Position, false, false);
            mdl.MarkAsNoLongerNeeded();
            if (dildoProp == null) return;

            float oX, oY, oZ, rX, rY, rZ;
            GetDildoPropOffsets(out oX, out oY, out oZ, out rX, out rY, out rZ);

            int boneIndex = Function.Call<int>(Hash.GET_PED_BONE_INDEX, player, 11816); // SKEL_Pelvis
            Function.Call(Hash.ATTACH_ENTITY_TO_ENTITY, dildoProp, player, boneIndex,
                oX, oY, oZ,       // offset X, Y, Z
                rX, rY, rZ,       // rotation X, Y, Z
                true, true, false, false, 2, true);
        }

        /// <summary>Per-animation dildo prop offset/rotation lookup.</summary>
        private void GetDildoPropOffsets(out float oX, out float oY, out float oZ,
            out float rX, out float rY, out float rZ)
        {
            // Default = standing BJ offsets (confirmed working)
            oX = 0.04f; oY = 0.13f; oZ = 0.0f;
            rX = 250.0f; rY = -35.0f; rZ = 0.0f;

            if (mode == Mode.Car)
            {
                if (currentAction == "blowjob")
                {
                    if (vehicleAnimType == VehicleAnimType.Low)
                    {
                        // Low car BJ — player reclined, girl leaning over
                        oX = 0.05f; oY = 0.15f; oZ = 0.0f;
                        rX = 260.0f; rY = -15.0f; rZ = 0.0f;
                    }
                    else
                    {
                        // Normal car BJ
                        oX = 0.04f; oY = 0.13f; oZ = 0.0f;
                        rX = 260.0f; rY = -35.0f; rZ = 0.0f;
                    }
                }
                else // sex
                {
                    if (vehicleAnimType == VehicleAnimType.Low)
                    {
                        // Low car sex — player reclined, girl riding
                        oX = 0.07f; oY = 0.14f; oZ = 0.01f;
                        rX = 270.0f; rY = -35.0f; rZ = 0.0f;
                    }
                    else
                    {
                        // Normal car sex
                        oX = 0.07f; oY = 0.14f; oZ = 0.025f;
                        rX = 280.0f; rY = -35.0f; rZ = 0.0f;
                    }
                }
            }
            else // Street
            {
                switch (streetActionIdx)
                {
                    // case 0: kissing — no dildo (already skipped)
                    // case 1: facesitting — no dildo (already skipped)
                    case 2: // Standing BJ
                        oX = 0.04f; oY = 0.13f; oZ = 0.0f;
                        rX = 250.0f; rY = -35.0f; rZ = 0.0f;
                        break;
                    case 3: // Sitting BJ
                        oX = 0.04f; oY = 0.13f; oZ = 0.0f;
                        rX = 260.0f; rY = -35.0f; rZ = 0.0f;
                        break;
                    case 4: // Laying BJ
                        oX = 0.09f; oY = 0.16f; oZ = 0.01f;
                        rX = 260.0f; rY = -5.0f; rZ = 0.0f;
                        break;
                    case 5: // Wall Banger
                        oX = 0.085f; oY = 0.15f; oZ = 0.03f;
                        rX = 283.0f; rY = -22.0f; rZ = 0.0f;
                        break;
                    case 6: // Sitting Cowgirl
                        oX = 0.07f; oY = 0.14f; oZ = 0.01f;
                        rX = 270.0f; rY = -35.0f; rZ = 0.0f;
                        break;
                    case 7: // Reverse Cowgirl
                        oX = 0.07f; oY = 0.14f; oZ = 0.01f;
                        rX = 270.0f; rY = 2.0f; rZ = 0.0f;
                        break;
                    case 8: // Laying Cowgirl
                        oX = 0.07f; oY = 0.14f; oZ = 0.01f;
                        rX = 270.0f; rY = 2.0f; rZ = 0.0f;
                        break;
                    case 9: // Laying Reversed
                        oX = 0.01f; oY = 0.14f; oZ = 0.01f;
                        rX = 270.0f; rY = -16.0f; rZ = 0.0f;
                        break;
                    case 10: // Doggy Style
                        oX = -0.01f; oY = 0.14f; oZ = 0.0f;
                        rX = 265.0f; rY = -50.0f; rZ = 0.0f;
                        break;
                    case 11: // Rough Doggy
                        oX = 0.08f; oY = 0.14f; oZ = 0.0f;
                        rX = 265.0f; rY = -15.0f; rZ = 0.0f;
                        break;
                }
            }
        }

        /// <summary>Detach and delete the dildo prop if it exists.</summary>
        private void DetachDildoProp()
        {
            if (dildoProp != null && dildoProp.Exists())
            {
                dildoProp.Detach();
                dildoProp.Delete();
            }
            dildoProp = null;
        }

        /// <summary>Find the nearest non-male ped within range.</summary>
        private Ped FindNearestFemale(Vector3 pos, float range)
        {
            Ped best = null;
            float bestDist = range;

            Ped[] nearby = World.GetNearbyPeds(pos, range);
            if (nearby == null) return null;

            foreach (Ped p in nearby)
            {
                if (p == null || !p.Exists()) continue;
                if (!p.IsAlive || p.IsInVehicle()) continue;
                if (p == Game.Player.Character) continue;

                // Check if female (IS_PED_MALE returns false)
                if (Function.Call<bool>(Hash.IS_PED_MALE, p)) continue;

                float d = p.Position.DistanceTo(pos);
                if (d < bestDist)
                {
                    bestDist = d;
                    best = p;
                }
            }
            return best;
        }

        /// <summary>Request and wait for an animation dictionary to load.</summary>
        private bool RequestAnimDict(string dict)
        {
            Function.Call(Hash.REQUEST_ANIM_DICT, dict);

            int timeout = 1000; // ms
            int start = Game.GameTime;
            while (!Function.Call<bool>(Hash.HAS_ANIM_DICT_LOADED, dict))
            {
                Wait(0);
                if (Game.GameTime - start > timeout)
                    return false;
            }
            return true;
        }

        /// <summary>Assign a random hooker voice to non-hooker peds. Hookers keep their default voice.</summary>
        private void AssignHookerVoice(Ped ped)
        {
            if (ped == null || !ped.Exists()) return;

            int model = ped.Model.Hash;
            int h1 = Game.GenerateHash("s_f_y_hooker_01");
            int h2 = Game.GenerateHash("s_f_y_hooker_02");
            int h3 = Game.GenerateHash("s_f_y_hooker_03");

            if (model == h1 || model == h2 || model == h3) return;

            int handle = ped.Handle;
            string voice;
            if (!voiceCache.TryGetValue(handle, out voice))
            {
                voice = HOOKER_VOICES[rng.Next(HOOKER_VOICES.Length)];
                voiceCache[handle] = voice;
            }
            Function.Call(Hash.SET_AMBIENT_VOICE_NAME, ped, voice);
        }

        /// <summary>Play ambient speech on a ped with Director Mode audio flag for non-hooker compatibility.</summary>
        private void PlayPedSpeech(Ped ped, string speechName)
        {
            if (ped == null || !ped.Exists()) return;
            Function.Call(Hash.STOP_CURRENT_PLAYING_AMBIENT_SPEECH, ped);
            Function.Call(Hash.SET_AUDIO_FLAG, "IsDirectorModeActive", true);
            Function.Call(Hash.PLAY_PED_AMBIENT_SPEECH_NATIVE, ped, speechName, "SPEECH_PARAMS_FORCE_SHOUTED", 0);
            Function.Call(Hash.SET_AUDIO_FLAG, "IsDirectorModeActive", false);
        }

        /// <summary>Play ambient speech moaning sounds on the girl.</summary>
        private void PlayMoaningSounds()
        {
            if (!femaleMoanVoice) return;
            if (girl == null || !girl.Exists() || currentAction == "" || currentAction == "kissing") return;

            // Re-apply hooker voice every time (Task.ClearAll can reset internal speech state)
            AssignHookerVoice(girl);

            // Use appropriate sounds based on action type
            string speechName = (currentAction == "blowjob") ? "SEX_ORAL_FEM" : "SEX_GENERIC_FEM";
            PlayPedSpeech(girl, speechName);
        }

        /// <summary>Play girl's service offer voice when opening services menu.</summary>
        private void PlayServiceVoice()
        {
            if (!femaleServiceVoice) return;
            if (girl == null || !girl.Exists()) return;

            AssignHookerVoice(girl);
            PlayPedSpeech(girl, "HOOKER_OFFER_SERVICE");
        }

        /// <summary>Play girl's finish voice line (skips kissing).</summary>
        private void PlayFinishSounds()
        {
            if (!femaleEndVoice) return;
            if (currentAction == "" || currentAction == "kissing") return;
            if (girl == null || !girl.Exists()) return;

            AssignHookerVoice(girl);
            PlayPedSpeech(girl, "SEX_FINISHED");
        }

        /// <summary>Release the girl back to the world.</summary>
        private void ReleaseGirl()
        {
            if (girl != null && girl.Exists())
            {
                Function.Call(Hash.SET_PED_KEEP_TASK, girl, false);
                girl.Task.ClearAll();
                girl.IsPositionFrozen = false;
                Function.Call(Hash.SET_ENTITY_COLLISION, girl, true, true);
                girl.BlockPermanentEvents = false;
                // Give her a wander task so AI doesn't re-queue the old vehicle enter
                girl.Task.WanderAround();
                girl.IsPersistent = false;
                girl.MarkAsNoLongerNeeded();
            }
            girl = null;
            hasGirl = false;
        }

        /// <summary>Full state reset.</summary>
        private void FullReset()
        {
            DetachDildoProp();
            ReleaseGirl();
            Function.Call(Hash.SET_EVERYONE_IGNORE_PLAYER, Game.Player, false);
            Function.Call(Hash.SET_PLAYER_CAN_DO_DRIVE_BY, Game.Player, true);

            Ped player = Game.Player.Character;
            player.IsPositionFrozen = false;
            Function.Call(Hash.SET_ENTITY_COLLISION, player, true, true);

            menuLevel = MenuLevel.None;
            state = ScriptState.Idle;
            mode = Mode.None;
            animPhase = 0;
            streetActionIdx = -1;
            lastPaidAmount = 0;
            playerWasInVehicle = false;
            approachPhase = 0;
            approachAnimWait = 0;
            approachSexySwapTime = 0;
            jHoldStart = 0;
            approachDict = "";
            carPropActive = false;
            carPropPhase = 0;
            carPropWaitTime = 0;
        }

        /// <summary>Draw the selection menu on screen.</summary>
        private void DrawMenu()
        {
            float x = 0.05f;
            float y = 0.05f;
            float lineHeight = 0.025f;

            DrawTextOnScreen("~y~====== 肉桂热咖啡 ======~s~", x, y);
            y += lineHeight * 2;

            if (menuLevel == MenuLevel.Main)
            {
                DrawMainMenu(x, ref y, lineHeight);
            }
            else if (menuLevel == MenuLevel.Services)
            {
                DrawServicesMenu(x, ref y, lineHeight);
            }

            y += lineHeight;
            string footerHint = "~b~[8/2]~s~ 移动  ~b~[5]~s~ 选择  ~b~[0]~s~ 返回  ~b~[J]~s~ 关闭";
            if (menuLevel == MenuLevel.Services && !sandboxMode)
                footerHint += "  ~b~[4/6]~s~ 移动";
            DrawTextOnScreen(footerHint, x, y);
        }

        private void DrawMainMenu(float x, ref float y, float lh)
        {
            int idx = 0;

            // -- Girl actions section --
            if (hasGirl)
            {
                DrawMenuItem("服务", idx, x, ref y, lh); idx++;
                DrawMenuItem("拒绝服务", idx, x, ref y, lh); idx++;
            }
            else
            {
                string searchLabel = sandboxMode ? "搜索附近NPC" : "寻找最近的妓女";
                DrawMenuItem(searchLabel, idx, x, ref y, lh); idx++;
            }

            // -- Separator --
            y += lh * 0.3f;
            DrawTextOnScreen("~s~    ============================", x, y);
            y += lh;

            // -- Settings section --
            string dickLabel = "切换男NPC显示: " + (dildoEnabled ? "~g~开启" : "~r~关闭") + "~s~";
            DrawMenuItem(dickLabel, idx, x, ref y, lh); idx++;

            string svcVoiceLabel = "服务语音（女声）'': " + (femaleServiceVoice ? "~g~开启" : "~r~关闭") + "~s~";
            DrawMenuItem(svcVoiceLabel, idx, x, ref y, lh); idx++;

            string moanVoiceLabel = "女性呻吟音效: " + (femaleMoanVoice ? "~g~开启" : "~r~关闭") + "~s~";
            DrawMenuItem(moanVoiceLabel, idx, x, ref y, lh); idx++;

            string voiceLabel = "完成时播放女性语音: " + (femaleEndVoice ? "~g~开启" : "~r~关闭") + "~s~";
            DrawMenuItem(voiceLabel, idx, x, ref y, lh); idx++;

            string driveLabel = "可驾驶车辆: " + (driveableCar ? "~g~开启" : "~r~关闭") + "~s~";
            DrawMenuItem(driveLabel, idx, x, ref y, lh); idx++;

            string modeLabel = "Mode: " + (sandboxMode ? "~b~沙盒模式" : "~o~卖淫模式") + "~s~";
            DrawMenuItem(modeLabel, idx, x, ref y, lh); idx++;

            // -- Help separator --
            y += lh * 0.3f;
            DrawTextOnScreen("~s~    ============================", x, y);
            y += lh;
            DrawTextOnScreen("~s~    ~r~使用数字小键盘导航!", x, y);
            y += lh;
        }

        private void DrawServicesMenu(float x, ref float y, float lh)
        {
            string[] items = (mode == Mode.Car) ? carServiceItems : streetServiceItems;
            bool isCar = (mode == Mode.Car);

            for (int i = 0; i < items.Length; i++)
            {
                string label = items[i];
                if (!sandboxMode)
                {
                    bool available = IsServiceAvailable(isCar, i);
                    if (!available)
                    {
                        label = "~c~" + label + "  ~r~(N/A)~s~";
                    }
                    else
                    {
                        int price = GetServicePrice(mode == Mode.Car, i);
                        bool locked = IsPriceLocked(mode == Mode.Car, i);

                        // Highlighted row: show swipe state (accept vs negotiate)
                        if (i == menuIndex && negotiateMode)
                        {
                            label += "  ~o~(Negotiate)~s~";
                        }
                        else
                        {
                            label += "  ~g~(Accept $" + price + ")~s~";
                        }
                    }
                }
                DrawMenuItem(label, i, x, ref y, lh);
            }
        }

        private void DrawMenuItem(string text, int itemIdx, float x, ref float y, float lh)
        {
            if (itemIdx == menuIndex)
                DrawTextOnScreen("~g~>> " + text + "~s~", x, y);
            else
                DrawTextOnScreen("    " + text, x, y);
            y += lh;
        }

        /// <summary>Draw text on screen using GTA V natives.</summary>
        private void DrawTextOnScreen(string text, float x, float y)
        {
            Function.Call(Hash.SET_TEXT_FONT, 0);
            Function.Call(Hash.SET_TEXT_SCALE, 0.4f, 0.4f);
            Function.Call(Hash.SET_TEXT_COLOUR, 255, 255, 255, 255);
            Function.Call(Hash.SET_TEXT_WRAP, 0.0f, 1.0f);
            Function.Call(Hash.SET_TEXT_CENTRE, false);
            Function.Call(Hash.SET_TEXT_DROPSHADOW, 2, 2, 0, 0, 0);
            Function.Call(Hash.SET_TEXT_EDGE, 1, 0, 0, 0, 205);
            Function.Call(Hash.BEGIN_TEXT_COMMAND_DISPLAY_TEXT, "STRING");
            // Split into 99-char chunks to avoid native string limit
            for (int i = 0; i < text.Length; i += 99)
            {
                string chunk = text.Substring(i, Math.Min(99, text.Length - i));
                Function.Call(Hash.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME, chunk);
            }
            Function.Call(Hash.END_TEXT_COMMAND_DISPLAY_TEXT, x, y, 0);
        }

        /// <summary>Show a timed subtitle.</summary>
        private void ShowSubtitle(string text, int duration)
        {
            GTA.UI.Screen.ShowSubtitle(text, duration);
        }
    }
}